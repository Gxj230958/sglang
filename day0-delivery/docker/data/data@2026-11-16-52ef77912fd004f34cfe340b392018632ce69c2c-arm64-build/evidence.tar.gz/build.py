import json
import os
from pathlib import Path
import signal
import subprocess
import time

root=Path(__file__).resolve().parent
plan=json.loads((root/'plan.json').read_text())
builder='glm5lp-fallback-52ef'
tag=plan['build_args']['SGLANG_IMAGE_TAG']
child=None
result={'runtime':plan['runtime'],'started':time.time(),'status':'running','tag':tag,'builder':builder}
def save():
    (root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
def interrupt(sig,frame):
    raise SystemExit(128+sig)
for sig in [signal.SIGTERM,signal.SIGINT]:signal.signal(sig,interrupt)
save()
try:
    (root/'buildkitd.toml').write_text('[worker.oci]\n  max-parallelism = 2\n')
    p=subprocess.run(['docker','buildx','create','--name',builder,'--driver','docker-container','--buildkitd-config',str(root/'buildkitd.toml')],capture_output=True,text=True,timeout=120)
    (root/'builder-create.log').write_text(p.stdout+p.stderr)
    assert p.returncode==0,p.stderr
    command=['docker','buildx','build','--builder',builder,'--platform','linux/arm64','--load','--progress','plain','--metadata-file',str(root/'build-metadata.json'),'--iidfile',str(root/'image-id'),'-f',str(root/'context/Dockerfile.fallback'),'-t',tag]
    for key,value in plan['build_args'].items():command+=['--build-arg',key+'='+value]
    command.append(str(root/'context'))
    (root/'build-command.json').write_text(json.dumps(command,indent=2)+'\n')
    with (root/'build.log').open('xb') as log:
        child=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        identity=Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()[19]
        (root/'build-client.json').write_text(json.dumps({'pid':child.pid,'start_ticks':identity,'started':time.time()},indent=2)+'\n')
        code=child.wait(timeout=plan['build_bound_hours']*3600)
    result['build_returncode']=code
    assert code==0,('docker build failed',code)
    inspect=subprocess.check_output(['docker','image','inspect',tag],text=True,timeout=60)
    (root/'image-inspect.json').write_text(inspect)
    record=json.loads(inspect)[0]
    assert record['Architecture']=='arm64'
    assert record['Config']['Labels']['org.opencontainers.image.revision']==plan['runtime']
    verify=subprocess.check_output(['docker','run','--rm','--entrypoint','cat',tag,'/opt/glm5lp/image-verification.json'],text=True,timeout=60)
    (root/'image-verification.json').write_text(verify)
    assert json.loads(verify)['revision']==plan['runtime']
    result.update(status='built_requires_gpu_validation',image_id=record['Id'])
except BaseException as error:
    result.update(status='failed',error=repr(error))
finally:
    for sig in [signal.SIGTERM,signal.SIGINT]:signal.signal(sig,signal.SIG_IGN)
    if child is not None and child.poll() is None:
        os.killpg(child.pid,signal.SIGTERM)
        try:child.wait(timeout=60)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
    try:
        stop=subprocess.run(['docker','buildx','stop',builder],capture_output=True,text=True,timeout=90)
        (root/'builder-stop.log').write_text(stop.stdout+stop.stderr)
        result['builder_stop_returncode']=stop.returncode
        if stop.returncode:result['status']='cleanup_unconfirmed'
    except Exception as error:
        result.update(status='cleanup_unconfirmed',cleanup_error=repr(error))
    result['finished']=time.time();save()
raise SystemExit(0 if result['status']=='built_requires_gpu_validation' else 1)
