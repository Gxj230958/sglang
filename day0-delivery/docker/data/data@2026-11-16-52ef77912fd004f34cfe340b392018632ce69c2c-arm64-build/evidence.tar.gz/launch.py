import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root=Path(__file__).resolve().parent
assert str(root)=='/home/ubuntu/glm5lp-fallback-image-52ef77912f'
assert not (root/'launch.json').exists()
files=json.loads((root/'driver-files.json').read_text())
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in files.items())
with (root/'driver.log').open('xb') as log:
    child=subprocess.Popen(['timeout','--signal=TERM','--kill-after=120s','7h','python3',str(root/'build.py')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record={'pid':child.pid,'start_ticks':Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()[19],'started':time.time()}
(root/'launch.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
