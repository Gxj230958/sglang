import hashlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path

root=Path('/sgl-workspace/sglang')
manifest=json.loads(Path('/opt/glm5lp/source-manifest.json').read_text())
assert os.environ['SGLANG_BUILD_COMMIT']==manifest['revision']
verified=[]
for name,spec in manifest['files'].items():
    if not (name.startswith('python/sglang/') and name.endswith('.py') or name.startswith('rust/') and Path(name).suffix in ('.rs','.toml','.lock','.h')):
        continue
    p=root/name
    data=os.readlink(p).encode() if spec['mode']=='120000' else p.read_bytes()
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==spec['oid'],name
    verified.append(name)
expected={'torch':'2.14.1+cu130','transformers':'5.19.0','flashinfer-python':'0.7.4','flashinfer-cubin':'0.7.4','flashinfer-jit-cache':'0.7.4+cu130','flashinfer-jit-cache-sm103a':'0.7.4+cu130','sglang-kernel':'0.4.11','sgl-deep-gemm':'0.2.8','sgl-flash-mla':'1.0.5','kernels':'0.14.1','mooncake-transfer-engine-cuda13':'0.3.13.post1'}
versions={name:metadata.version(name) for name in expected}
assert versions==expected,versions
assert os.environ['SGLANG_RUST_BUILD_MODE']=='never'
from sglang.srt.mem_cache.rust_tree_core.extension import bindings
native=Path(bindings.__file__).resolve()
assert native.is_relative_to(root/'python/sglang/srt/mem_cache/rust_tree_core'),str(native)
from flashinfer_jit_cache import get_jit_cache_providers
providers=[{'id':p.provider_id,'version':p.version,'path':str(p.jit_cache_dir)} for p in get_jit_cache_providers()]
assert any(p['id']=='sm103a' and p['version']=='0.7.4+cu130' for p in providers),providers
print(json.dumps({'revision':manifest['revision'],'versions':versions,'verified_source_files':len(verified),'rust_extension':str(native),'rust_sha256':hashlib.sha256(native.read_bytes()).hexdigest(),'jit_providers':providers,'scope':'CPU image construction verification; GPU serve/evaluation required separately.'},indent=2))
