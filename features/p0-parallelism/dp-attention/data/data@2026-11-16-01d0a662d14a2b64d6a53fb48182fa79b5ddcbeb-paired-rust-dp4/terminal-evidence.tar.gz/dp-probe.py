import json
from pathlib import Path
import random
import re
import sys
import urllib.request

endpoint,model,output=sys.argv[1:]
output=Path(output)
output.mkdir(exist_ok=False)
log=output.parent/'replica-0.log'
rng=random.Random('rust-dp4-prefix-v1')
codes=[rng.randrange(100000,999999) for _ in range(507)]
alternate=[rng.randrange(100000,999999) for _ in codes]
forked=codes[:253]+alternate[253:]
rows=[]
for rank in range(4):
    for phase,values,index in [('cold',codes,169),('warm',codes,169),('fork',forked,500),('warm-fork',forked,500)]:
        name=f'rank-{rank}-{phase}'
        prompt='Session rust-dp4-prefix-v1.\n'+'\n'.join(f'Record {i}: the code is {value}.' for i,value in enumerate(values))
        prompt+=f'\n\nWhat is the code of Record {index}? Answer with the number only.'
        body={'model':model,'messages':[{'role':'user','content':prompt}],'temperature':0,'seed':1,'max_tokens':512,'routed_dp_rank':rank,'chat_template_kwargs':{'enable_thinking':False},'return_output_ids_in_sglext':True}
        (output/(name+'-request.json')).write_text(json.dumps(body,indent=2))
        begin=log.stat().st_size
        req=urllib.request.Request(endpoint+'/v1/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=1800) as response: result=json.load(response)
        (output/(name+'-response.json')).write_text(json.dumps(result,indent=2))
        with log.open('rb') as stream:
            stream.seek(begin)
            window=stream.read().decode(errors='replace')
        (output/(name+'-server.log')).write_text(window)
        seen=sorted({int(m[1]) for line in window.splitlines() if 'Prefill batch,' in line and (m:=re.search(r'DP(\d+)',line))})
        choice=result['choices'][0]
        cached=result['usage']['prompt_tokens_details']['cached_tokens']
        cache_pass=cached==0 if phase=='cold' else cached>0 if phase in ('warm','warm-fork') else True
        rows.append({'rank':rank,'phase':phase,'expected':str(values[index]),'correct':(choice['message'].get('content') or '').strip()==str(values[index]),'finish_reason':choice['finish_reason'],'cached_tokens':cached,'routing_dp_ranks':seen,'routing_pass':seen==[rank],'cache_pass':cache_pass})
        (output/'rows.json').write_text(json.dumps(rows,indent=2))
gates={'correct_and_stop':all(x['correct'] and x['finish_reason']=='stop' for x in rows),'cache_isolation_and_reuse':all(x['cache_pass'] for x in rows),'actual_dp_routing':all(x['routing_pass'] for x in rows)}
(output/'result.json').write_text(json.dumps({'requests':len(rows),'gates':gates,'rows':rows},indent=2))
print(json.dumps(gates))
