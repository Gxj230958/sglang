import hashlib,json,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
assert str(root)=='/scratch/glm5lp-dp4-rust-01d0a662d1'
assert not (root/'driver.pid').exists() and not (root/'results').exists()
prior=Path('/scratch/glm5lp-hicache-full-01d0a662d1')
assert (prior/'driver.exit').read_text().strip()=='0'
assert not Path('/proc/'+(prior/'driver.pid').read_text().strip()).exists()
assert not json.loads((prior/'cleanup.json').read_text())['remaining_pids']
assert json.loads((prior/'postrun-source-verification.json').read_text())['mismatches']==[]
files=json.loads((root/'files.json').read_text())
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in files.items())
probe=json.loads(subprocess.check_output(['python3',str(root/'idle-probe.py')]))
assert probe['idle'],probe
(root/'launcher-idle.json').write_text(json.dumps(probe,indent=2))
p=subprocess.Popen(['bash',str(root/'start.sh')],stdin=subprocess.DEVNULL,stdout=(root/'driver.log').open('wb'),stderr=subprocess.STDOUT,start_new_session=True)
(root/'driver.pid').write_text(str(p.pid))
result={'pid':p.pid,'started':time.time(),'root':str(root),'verified_inputs':len(files)}
(root/'launch.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
