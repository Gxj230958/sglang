import json
import os
import subprocess
from pathlib import Path

excluded = {os.getpid()}
pid = os.getpid()
while pid > 1:
    try:
        stat = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        pid = int(stat[1])
        excluded.add(pid)
    except (OSError, ValueError):
        break
blocked = []
for d in Path('/proc').iterdir():
    if not d.name.isdigit() or int(d.name) in excluded:
        continue
    try:
        argv = (d / 'cmdline').read_bytes().decode(errors='replace').split('\0')
        comm = (d / 'comm').read_text().strip()
    except (OSError, ProcessLookupError):
        continue
    if not argv or not argv[0]:
        continue
    python_job = comm.startswith(('python', 'sglang')) and not any('mutagen' in a for a in argv)
    scratch_driver = Path(argv[0]).name in ('bash', 'sh', 'zsh') and any('/scratch/' in a for a in argv[1:])
    if python_job or scratch_driver:
        blocked.append({'pid': int(d.name), 'comm': comm, 'entry': next((Path(a).name for a in argv[1:] if a.endswith(('.py', '.sh'))), '')})
p = subprocess.run(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader,nounits'], capture_output=True, text=True)
m = subprocess.run(['nvidia-smi', '--query-gpu=memory.used', '--format=csv,noheader,nounits'], capture_output=True, text=True)
try:
    memory = [int(x.strip()) for x in m.stdout.splitlines()]
except ValueError:
    memory = []
idle = p.returncode == 0 and m.returncode == 0 and not p.stdout.strip() and len(memory) == 4 and max(memory) < 2000 and not blocked
print(json.dumps({'idle': idle, 'blocked': blocked, 'memory_mib': memory, 'gpu_pids': p.stdout.splitlines()}))
