import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import traceback
import urllib.request

root=Path(__file__).resolve().parent
plan=json.loads((root/'plan.json').read_text())
env=dict(os.environ,**plan['environment'],CUDA_VISIBLE_DEVICES='0,1,2,3',OMP_NUM_THREADS='4')
for key in list(env):
    if key.startswith('SGLANG_SIMULATE_ACC_') or key=='SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND':
        env.pop(key)
endpoint='http://127.0.0.1:32010'
server=None

def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')

def request(resource,body=None):
    data=None if body is None else json.dumps(body).encode()
    req=urllib.request.Request(endpoint+'/'+resource,data=data,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=5) as response:
        return response.read()

def stop():
    global server
    if server is None:
        return
    try:
        os.killpg(server.pid,signal.SIGTERM)
        try:
            server.wait(timeout=30)
        except subprocess.TimeoutExpired:
            pass
        os.killpg(server.pid,signal.SIGKILL)
    except ProcessLookupError:
        pass
    server.wait(timeout=10)
    server=None

def interrupted(signum,frame):
    raise SystemExit(128+signum)

def command(folder,name,args,timeout,command_env=env):
    write(folder/(name+'-command.json'),args)
    with (folder/(name+'.log')).open('wb') as log:
        subprocess.run(args,env=command_env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,check=True)

for sig in [signal.SIGTERM,signal.SIGINT]:
    signal.signal(sig,interrupted)

result={'runtime':plan['runtime'],'started':time.time(),'candidates':[]}
try:
    for candidate in plan['candidates']:
        folder=root/'results'/candidate['name']
        folder.mkdir(parents=True,exist_ok=False)
        for port in [32010,32011]:
            with socket.socket() as sock:
                sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
                sock.bind(('127.0.0.1',port))
        args=[sys.executable,str(root/'server.py'),str(folder),*candidate['args']]
        write(folder/'launch.json',{'command':args,'environment':{k:v for k,v in env.items() if k in plan['environment'] or k in ['CUDA_VISIBLE_DEVICES','OMP_NUM_THREADS','GLM5LP_SWEEP_OWNER']}})
        with (folder/'replica-0.log').open('wb') as log:
            server=subprocess.Popen(args,cwd=plan['source'],env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        write(folder/'server-process.json',{'pid':server.pid,'pgid':server.pid})
        deadline=time.monotonic()+1800
        ready=False
        while time.monotonic()<deadline:
            assert server.poll() is None,('server exited',server.returncode)
            try:
                request('health')
                ready=True
                break
            except (OSError,TimeoutError):
                time.sleep(5)
        assert ready,'startup deadline exceeded'
        command(folder,'sanity',[sys.executable,str(root/'rust-sanity.py'),endpoint,candidate['model'],str(folder/'correctness.json'),json.dumps(candidate['expected'])],600)
        assert json.loads((folder/'correctness.json').read_text())=={'stop_rate':1.0,'empty_rate':0.0,'error_rate':0.0}
        command(folder,'retrieval',[sys.executable,str(root/'probe.py'),endpoint+'/v1',str(folder/'retrieval.json'),'300','3000','9000','24000','60000','110000'],3600)
        rows=json.loads((folder/'retrieval.json').read_text())
        assert len(rows)==18,'incomplete retrieval protocol'
        retrieval_passed=all((x.get('text') or '').strip()==x['expected'] and x['finish_reason']=='stop' for x in rows)
        request('flush_cache',{})
        command(folder,'dp-probes',[sys.executable,str(root/'dp-probe.py'),endpoint,candidate['model'],str(folder/'dp-probes')],3600)
        dp_probes=json.loads((folder/'dp-probes/result.json').read_text())
        request('flush_cache',{})
        (folder/'metrics-before.txt').write_bytes(request('metrics'))
        eval_env=dict(os.environ,PYTHONPATH='',PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='',OPENAI_API_KEY='dummy')
        args=[plan['eval_executable'],'run','gsm8k','--base-url',endpoint+'/v1','--model',candidate['model'],'--temperature','1.0','--top-p','0.95','--seed','1','--num-threads','64','--max-tokens','32768','--out-dir',str(folder/'gsm8k')]
        command(folder,'gsm8k',args,10800,eval_env)
        metrics_files=list((folder/'gsm8k').rglob('metrics.json'))
        predictions=list((folder/'gsm8k').rglob('output-rs0.jsonl'))
        assert len(metrics_files)==len(predictions)==1
        metrics=json.loads(metrics_files[0].read_text())
        rows=[json.loads(line) for line in predictions[0].read_text().splitlines()]
        assert len(rows)==1319 and {x['id'] for x in rows}=={f'gsm8k-{i}' for i in range(1319)}
        assert metrics['aggregate']['error_rate']==0,metrics['aggregate']
        assert all(x['finish_reason'] in ('stop','length') for x in rows)
        (folder/'metrics-after.txt').write_bytes(request('metrics'))
        (folder/'server-info-final.json').write_bytes(request('get_server_info'))
        result['candidates'].append({'name':candidate['name'],'status':'measurements_complete_review_required','retrieval_gate_passed':retrieval_passed,'dp_probe_gates':dp_probes['gates']})
        write(root/'result.json',result)
        stop()
        time.sleep(5)
    result['status']='measurements_complete_review_required'
except BaseException as error:
    result.update(status='failed',error=repr(error),traceback=traceback.format_exc())
    print(result['traceback'],flush=True)
finally:
    stop()
    result['finished']=time.time()
    write(root/'result.json',result)
raise SystemExit(0 if result.get('status')=='measurements_complete_review_required' else 1)
