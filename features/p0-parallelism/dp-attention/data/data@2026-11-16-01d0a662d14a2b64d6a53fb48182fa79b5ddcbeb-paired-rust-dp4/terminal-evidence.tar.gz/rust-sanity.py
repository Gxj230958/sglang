import hashlib,json,pathlib,re,subprocess,sys
out=pathlib.Path(sys.argv[3]).parent
log=(out/'replica-0.log').read_text(errors='replace')
lines=[line for line in log.splitlines() if 'Init Unified Radix Cache.' in line and 'Tree Core:' in line]
assert lines,'missing tree-core initialization evidence'
assert all('Tree Core: RustUnifiedTreeCore' in line for line in lines),lines
matches=[re.search(r'DP(\d+) TP(\d+) EP(\d+) PID(\d+)',line) for line in lines]
assert all(matches),lines
assert {(int(m[1]),int(m[2]),int(m[3])) for m in matches}=={(i,i,i) for i in range(4)}
ranks={int(m[1]):int(m[4]) for m in matches}
assert set(ranks)==set(range(4)),ranks
record={'selected':'rust','lines':lines,'ranks':{}}
for rank,pid in ranks.items():
 maps=pathlib.Path(f'/proc/{pid}/maps').read_text()
 paths=sorted({line.split()[-1] for line in maps.splitlines() if 'mem_cache' in line and '.so' in line})
 assert paths,('Rust shared object not mapped',rank,pid)
 record['ranks'][rank]={'pid':pid,'extensions':[{'path':p,'sha256':hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()} for p in paths]}
(out/'tree-core.json').write_text(json.dumps(record,indent=2))
subprocess.run([sys.executable,str(pathlib.Path(__file__).with_name('sanity.py')),*sys.argv[1:]],check=True)
