# Serve sweep report

Recommended: `nvfp4-tp4-fp8kv-mtp-natural`

## fp8-tp4-fp8kv-mtp-natural

Best level: `1`; metrics: `{'accept_length': 2.4380952380952383, 'cache_hit': 0.7791, 'cached': 179008, 'duration_s': 78.67474572593346, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 229772, 'interactivity_p90': 125.48320666931815, 'level': 1, 'ok': 64, 'ok_ratio': 1.0, 'output': 8192, 'output_tps': 104.1248996029444, 'sent': 64, 'total_tps': 3024.6554698626783, 'total_tps_per_gpu': 756.1638674656696, 'ttft_p50': 0.4143471885472536, 'ttft_p90': 0.4260546311736107}`
Valid points: 1

## nvfp4-tp4-fp8kv-mtp-natural

Best level: `1`; metrics: `{'accept_length': 2.5091463414634148, 'cache_hit': 0.7765000000000001, 'cached': 178432, 'duration_s': 74.07655563997105, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 229793, 'interactivity_p90': 137.7571482391744, 'level': 1, 'ok': 64, 'ok_ratio': 1.0, 'output': 8192, 'output_tps': 110.5882951660845, 'sent': 64, 'total_tps': 3212.689871228103, 'total_tps_per_gpu': 803.1724678070258, 'ttft_p50': 0.42700995528139174, 'ttft_p90': 0.440662258816883}`
Valid points: 1

## fp8-dep4-fp8kv-mtp-natural

Best level: `1`; metrics: `{'accept_length': 2.2704545454545455, 'cache_hit': 0.42119999999999996, 'cached': 96768, 'duration_s': 129.3565038992092, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 229754, 'interactivity_p90': 82.53192264917874, 'level': 1, 'ok': 64, 'ok_ratio': 1.0, 'output': 8192, 'output_tps': 63.328860575754014, 'sent': 64, 'total_tps': 1839.4591135935505, 'total_tps_per_gpu': 459.8647783983876, 'ttft_p50': 0.9081925041973591, 'ttft_p90': 0.987237966246903}`
Valid points: 1

## nvfp4-dep4-fp8kv-mtp-natural

Best level: `1`; metrics: `{'accept_length': 2.5776315789473685, 'cache_hit': 0.4211, 'cached': 96768, 'duration_s': 115.79001218499616, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 229803, 'interactivity_p90': 93.08349789443524, 'level': 1, 'ok': 64, 'ok_ratio': 1.0, 'output': 8192, 'output_tps': 70.74876187863035, 'sent': 64, 'total_tps': 2055.401804602616, 'total_tps_per_gpu': 513.850451150654, 'ttft_p50': 0.9239921104162931, 'ttft_p90': 0.986866133287549}`
Valid points: 1
