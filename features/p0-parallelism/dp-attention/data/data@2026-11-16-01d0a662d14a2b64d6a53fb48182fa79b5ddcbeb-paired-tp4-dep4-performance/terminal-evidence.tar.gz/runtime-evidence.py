import hashlib,json,pathlib,re,subprocess,sys
out=pathlib.Path(sys.argv[3]).parent
log=(out/'replica-0.log').read_text(errors='replace')
lines=[line for line in log.splitlines() if 'Init Unified Radix Cache.' in line and 'Tree Core:' in line]
assert lines,'missing tree-core initialization evidence'
assert all('Tree Core: RustUnifiedTreeCore' in line for line in lines),lines
ranks={int(m[1]):int(m[2]) for line in lines if (m:=re.search(r'TP(\d+)(?: EP\d+)? PID(\d+)',line))}
assert set(ranks)==set(range(4)),ranks
expected=json.loads(sys.argv[4])
if expected['attn_dp_size']==4:
 assert all(any(re.search(fr'DP{rank} TP{rank} EP{rank} PID{pid}\]',line) for line in lines) for rank,pid in ranks.items())
record={'selected':'rust','lines':lines,'ranks':{}}
for rank,pid in ranks.items():
 maps=pathlib.Path(f'/proc/{pid}/maps').read_text()
 paths=sorted({line.split()[-1] for line in maps.splitlines() if 'mem_cache' in line and '.so' in line})
 assert paths,('Rust shared object not mapped',rank,pid)
 record['ranks'][rank]={'pid':pid,'extensions':[{'path':p,'sha256':hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()} for p in paths]}
(out/'tree-core.json').write_text(json.dumps(record,indent=2))
import urllib.request
with urllib.request.urlopen(sys.argv[1]+'/get_server_info',timeout=10) as response: info=json.load(response)
expected=json.loads(sys.argv[4])
assert all(info.get(k)==v for k,v in expected.items()),{k:info.get(k) for k in expected}
record['resolved']={k:info[k] for k in expected}
record['simulation']=json.loads((out/'server-imports.json').read_text())['simulation']
pathlib.Path(sys.argv[3]).write_text(json.dumps(record,indent=2))
