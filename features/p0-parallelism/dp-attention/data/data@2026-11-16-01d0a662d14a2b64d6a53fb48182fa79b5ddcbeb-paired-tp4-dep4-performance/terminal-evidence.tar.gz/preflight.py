import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
plan = json.loads((root/'plan.json').read_text())
files = json.loads((root/'files.json').read_text())
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest() == digest for name,digest in files.items())
prior = Path(plan['predecessor'])
assert (prior/'driver.exit').read_text().strip() == '0'
assert not Path('/proc/' + (prior/'driver.pid').read_text().strip()).exists()
assert not json.loads((prior/'cleanup.json').read_text())['remaining_pids']
assert not json.loads((prior/'postrun-source-verification.json').read_text())['mismatches']
result = json.loads((prior/'result.json').read_text())
assert result['status'] == 'measurements_complete_review_required' and len(result['candidates']) == 2
assert all(c['status'] == 'measurements_complete_review_required' for c in result['candidates'])
idle = json.loads(subprocess.check_output(['python3',str(root/'idle-probe.py')],text=True))
assert idle['idle'],idle
source = Path(plan['source'])
verification = json.loads(subprocess.check_output(['python3',str(source/'verify_source.py'),str(source/'source-manifest.json'),str(source/'src')],text=True))
assert not verification['mismatches']
for precision,path in plan['models'].items():
    assert {n:hashlib.sha256((Path(path)/n).read_bytes()).hexdigest() for n in plan['model_metadata'][precision]} == plan['model_metadata'][precision]
env = dict(os.environ, **plan['environment'])
script = 'import importlib.metadata as m,json,sys; print(json.dumps({n:m.version(n) for n in json.loads(sys.argv[1])}))'
versions = json.loads(subprocess.check_output(['/opt/sglang/bin/python','-c',script,json.dumps(list(plan['package_versions']))],env=env,text=True))
assert versions == plan['package_versions']
(root/'preflight.json').write_text(json.dumps({'inputs':len(files),'idle':idle,'source':verification,'versions':versions},indent=2)+'\n')
print(json.dumps({'inputs':len(files),'idle':True,'source_files':verification.get('checked')}))
