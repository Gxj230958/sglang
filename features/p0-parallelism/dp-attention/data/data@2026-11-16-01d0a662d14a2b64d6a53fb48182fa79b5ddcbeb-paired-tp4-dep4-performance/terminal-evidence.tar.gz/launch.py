import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
assert str(root)=='/scratch/glm5lp-paired-parallelism-01d0a662d1'
assert not (root/'driver.pid').exists()
files=json.loads((root/'files.json').read_text())
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in files.items())
subprocess.run(['python3',str(root/'preflight.py')],check=True)
env=dict(os.environ)
for k in list(env):
    if k.startswith('SGLANG_SIMULATE_ACC_') or k=='SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND':env.pop(k)
p=subprocess.Popen(['timeout','--signal=TERM','--kill-after=90s','6h','bash',str(root/'start.sh')],env=env,stdin=subprocess.DEVNULL,stdout=(root/'driver.log').open('wb'),stderr=subprocess.STDOUT,start_new_session=True)
(root/'driver.pid').write_text(str(p.pid))
record={'pid':p.pid,'started':time.time(),'root':str(root),'files_verified':len(files)}
(root/'launch.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record))
