# Serve sweep report

Recommended: `nvfp4-tp4-fp8kv-mtp-controlled35`

## fp8-tp4-fp8kv-mtp-controlled35

Best level: `32`; metrics: `{'accept_length': 3.5, 'cache_hit': 0.76955, 'cached': 1414080, 'duration_s': 30.05043419217691, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1837528, 'interactivity_p90': 66.4831256850145, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 1090.6133848151912, 'sent': 512, 'total_tps': 31669.686116658857, 'total_tps_per_gpu': 7917.421529164714, 'ttft_p50': 1.9484799562487751, 'ttft_p90': 2.3027416875120252}`
Valid points: 6

## nvfp4-tp4-fp8kv-mtp-controlled35

Best level: `32`; metrics: `{'accept_length': 3.5, 'cache_hit': 0.7636499999999999, 'cached': 1403200, 'duration_s': 29.934755532536656, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1837460, 'interactivity_p90': 86.39103233343374, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 1105.0754261590516, 'sent': 512, 'total_tps': 32088.303936728204, 'total_tps_per_gpu': 8022.075984182051, 'ttft_p50': 2.1595258683664724, 'ttft_p90': 2.440550446161069}`
Valid points: 6

## fp8-dep4-fp8kv-mtp-controlled35

Best level: `16`; metrics: `{'accept_length': 3.567857142857143, 'cache_hit': 0.54365, 'cached': 499648, 'duration_s': 28.49387789797038, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 919023, 'interactivity_p90': 63.78970040602509, 'level': 16.0, 'ok': 256, 'ok_ratio': 1.0, 'output': 32768, 'output_tps': 575.43043625052, 'sent': 256, 'total_tps': 16714.147342612534, 'total_tps_per_gpu': 4178.5368356531335, 'ttft_p50': 1.8094669519923627, 'ttft_p90': 2.7402727531036364}`
Valid points: 5

## nvfp4-dep4-fp8kv-mtp-controlled35

Best level: `16`; metrics: `{'accept_length': 3.567857142857143, 'cache_hit': 0.5544, 'cached': 509440, 'duration_s': 27.247249078471214, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 918917, 'interactivity_p90': 79.2473523002015, 'level': 16.0, 'ok': 256, 'ok_ratio': 1.0, 'output': 32768, 'output_tps': 602.4238810091465, 'sent': 256, 'total_tps': 17496.170985705932, 'total_tps_per_gpu': 4374.042746426483, 'ttft_p50': 2.027009724988602, 'ttft_p90': 2.602495384030044}`
Valid points: 5
