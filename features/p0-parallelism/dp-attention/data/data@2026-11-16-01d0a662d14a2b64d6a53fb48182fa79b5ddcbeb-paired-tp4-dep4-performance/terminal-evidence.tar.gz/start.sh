#!/usr/bin/env bash
set -euo pipefail
R=/scratch/glm5lp-paired-parallelism-01d0a662d1
S=/scratch/glm5lp-cp4-rust-01d0a662d1
P=/scratch/glm5lp-dp4-rust-01d0a662d1
test ! -d "$R/gate"
test ! -d "$R/off"
test ! -d "$R/controlled"
export GLM5LP_SWEEP_OWNER="$(cat "$R/process-owner.txt")"
export PATH=/root/.cargo/bin:$PATH
export HF_HOME="$S/cache/huggingface"
finish() {
  rc=$?
  trap - EXIT
  python3 "$R/cleanup.py" "$R/cleanup.json" || rc=125
  nvidia-smi --query-compute-apps=pid,process_name --format=csv,noheader > "$R/gpu-final-processes.csv" || rc=125
  nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits > "$R/gpu-final-memory.csv" || rc=125
  printf '%s\n' "$rc" > "$R/driver.exit"
  exit "$rc"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
python3 "$R/preflight.py"
cd "$R"
python3 -u execute.py run --config natural-gate.json --run-dir "$R/gate"
python3 -c 'import json,sys; r=json.load(open(sys.argv[1])); assert not r["failures"] and len(r["candidates"])==4; assert all(len(x["points"])==1 and x["points"][0]["pass"] for x in r["candidates"])' "$R/gate/report.json"
python3 -u execute.py run --config mtp-off.json --run-dir "$R/off"
python3 -c 'import json,sys; r=json.load(open(sys.argv[1])); assert not r["failures"] and len(r["candidates"])==4; assert all(len(x["points"])==6 for x in r["candidates"])' "$R/off/report.json"
python3 -u execute.py run --config controlled35.json --run-dir "$R/controlled"
python3 -c 'import json,sys; r=json.load(open(sys.argv[1])); assert not r["failures"] and len(r["candidates"])==4; assert all(len(x["points"])==6 for x in r["candidates"])' "$R/controlled/report.json"
python3 "$S/verify_source.py" "$S/source-manifest.json" "$S/src" > "$R/postrun-source-verification.json"
