# Serve sweep report

Recommended: `nvfp4-tp4-fp8kv-mtp-off`

## fp8-tp4-fp8kv-mtp-off

Best level: `32`; metrics: `{'cache_hit': 0.77125, 'cached': 1417664, 'duration_s': 45.73062659497373, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838164, 'interactivity_p90': 32.75243503259768, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 716.5599426387937, 'sent': 512, 'total_tps': 20814.74635476767, 'total_tps_per_gpu': 5203.686588691918, 'ttft_p50': 1.7899912488646805, 'ttft_p90': 2.212019457365386}`
Valid points: 6

## nvfp4-tp4-fp8kv-mtp-off

Best level: `32`; metrics: `{'cache_hit': 0.7665, 'cached': 1408960, 'duration_s': 39.202048991341144, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838190, 'interactivity_p90': 42.34578313390885, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 835.8750851166099, 'sent': 512, 'total_tps': 24280.962101573226, 'total_tps_per_gpu': 6070.240525393307, 'ttft_p50': 1.7520517443772405, 'ttft_p90': 2.1936976816505194}`
Valid points: 6

## fp8-dep4-fp8kv-mtp-off

Best level: `16`; metrics: `{'cache_hit': 0.56795, 'cached': 521984, 'duration_s': 45.06029558600858, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 919069, 'interactivity_p90': 33.24661541237711, 'level': 16.0, 'ok': 256, 'ok_ratio': 1.0, 'output': 32768, 'output_tps': 363.61202206996336, 'sent': 256, 'total_tps': 10562.115285900514, 'total_tps_per_gpu': 2640.5288214751286, 'ttft_p50': 1.8017623017076403, 'ttft_p90': 2.4637330458965154}`
Valid points: 5

## nvfp4-dep4-fp8kv-mtp-off

Best level: `16`; metrics: `{'cache_hit': 0.5985, 'cached': 550080, 'duration_s': 39.22057775501162, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 919080, 'interactivity_p90': 40.528427991444154, 'level': 16.0, 'ok': 256, 'ok_ratio': 1.0, 'output': 32768, 'output_tps': 418.1323955213817, 'sent': 256, 'total_tps': 12145.958442707637, 'total_tps_per_gpu': 3036.4896106769093, 'ttft_p50': 1.9421615317696705, 'ttft_p90': 2.2421599286608394}`
Valid points: 5
