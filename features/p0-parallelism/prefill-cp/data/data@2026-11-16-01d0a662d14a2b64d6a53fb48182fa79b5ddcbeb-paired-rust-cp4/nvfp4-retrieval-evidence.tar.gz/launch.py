import hashlib,json,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
assert str(root)=='/scratch/glm5lp-cp4-nvfp4-rust-01d0a662d1'
assert not (root/'driver.pid').exists() and not (root/'results').exists()
prior=Path('/scratch/glm5lp-cp4-rust-01d0a662d1')
assert (prior/'driver.exit').read_text().strip()=='1'
assert not Path('/proc/'+(prior/'driver.pid').read_text().strip()).exists()
assert not json.loads((prior/'cleanup.json').read_text())['remaining_pids']
result=json.loads((prior/'result.json').read_text())
assert [c['name'] for c in result['candidates']]==['fp8-cp4']
assert not (prior/'results/nvfp4-cp4/server-process.json').exists()
assert json.loads((prior/'preparation.json').read_text())['status']=='passed'
files=json.loads((root/'files.json').read_text())
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in files.items())
probe=json.loads(subprocess.check_output(['python3',str(root/'idle-probe.py')]))
assert probe['idle'],probe
(root/'launcher-idle.json').write_text(json.dumps(probe,indent=2))
p=subprocess.Popen(['bash',str(root/'start.sh')],stdin=subprocess.DEVNULL,stdout=(root/'driver.log').open('wb'),stderr=subprocess.STDOUT,start_new_session=True)
(root/'driver.pid').write_text(str(p.pid))
record={'pid':p.pid,'started':time.time(),'root':str(root),'files_verified':len(files),'prior':str(prior),'prelaunch':probe}
(root/'launch.json').write_text(json.dumps(record,indent=2));print(json.dumps(record))
