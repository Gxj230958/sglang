import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
state=json.loads((root/'preparation-first.json').read_text())
plan=json.loads((root/'plan.json').read_text())
assert state['error']=="TypeError(\"dict() got multiple values for keyword argument 'PYTHONNOUSERSITE'\")"
assert state['checkpoints']['fp8']['files']==142 and state['checkpoints']['nvfp4']['files']==163
assert state['fp8_metadata']['passed']
state['prior_attempt']='preparation-first.json'
state.pop('error')
state['resumed']=time.time()
try:
    state['source']=json.loads(subprocess.check_output(['python3',str(root/'verify_source.py'),str(root/'source-manifest.json'),str(root/'src')]))
    assert not state['source']['mismatches'] and state['source']['revision']==plan['runtime']
    env=dict(os.environ,**plan['environment'])
    env['PATH']='/root/.cargo/bin:'+env['PATH']
    for key in list(env):
        if key.startswith('SGLANG_SIMULATE_ACC_') or key=='SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND':env.pop(key)
    code='from sglang.srt.mem_cache.rust_tree_core.extension import bindings; print(bindings.__file__)'
    with (root/'rust-build.log').open('wb') as log:
        path=subprocess.check_output(['/opt/sglang/bin/python','-c',code],env=env,stderr=log,timeout=600).decode().strip().splitlines()[-1]
    state['rust_extension']={'path':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()}
    code='import importlib.metadata as m; print(m.version("sgl-eval"))'
    version=subprocess.check_output(['/scratch/cc-swa/evalenv/bin/python','-c',code],env=dict(os.environ,PYTHONPATH='',PYTHONNOUSERSITE='1')).decode().strip()
    assert version=='0.1.3',version
    state['eval_version']=version
    state['status']='passed'
except BaseException as error:
    state.update(status='failed',error=repr(error))
    raise
finally:
    state['finished']=time.time()
    (root/'preparation.json').write_text(json.dumps(state,indent=2))
