#!/usr/bin/env bash
set -euo pipefail
R=/scratch/glm5lp-cp4-rust-01d0a662d1
S=$R
test ! -d "$R/results"
export GLM5LP_SWEEP_OWNER=glm5lp-cp4-rust-01d0a662d1
export PATH=/root/.cargo/bin:$PATH
export HF_HOME="$R/cache/huggingface"
finish() {
  rc=$?
  trap - EXIT
  python3 "$R/cleanup.py" "$R/cleanup.json" || rc=125
  nvidia-smi --query-compute-apps=pid,process_name --format=csv,noheader > "$R/gpu-final-processes.csv" || rc=125
  nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits > "$R/gpu-final-memory.csv" || rc=125
  printf '%s\n' "$rc" > "$R/driver.exit"
  exit "$rc"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
python3 "$R/idle-probe.py" > "$R/prelaunch-probe.json"
python3 -c 'import json,sys; assert json.load(open(sys.argv[1]))["idle"]' "$R/prelaunch-probe.json"
python3 "$S/verify_source.py" "$S/source-manifest.json" "$S/src" > "$R/source-verification.json"
test "$(cat "$R/preparation.exit")" = 0
timeout --signal=TERM --kill-after=90s 6h /opt/sglang/bin/python -u "$R/run.py"
