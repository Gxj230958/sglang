import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
prior = Path('/scratch/codex-humanx-perf')
plan = json.loads((root / 'plan.json').read_text())
state = {'started': time.time(), 'runtime': plan['runtime'], 'checkpoints': {}}

def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()

def verify(item):
    model, record = item
    path = model / record['name']
    assert path.stat().st_size == record['size'], record['name']
    assert digest(path) == record['sha256'], record['name']
    return record['size']

try:
    state['source'] = json.loads(subprocess.check_output([sys.executable, str(root / 'verify_source.py'), str(root / 'source-manifest.json'), str(root / 'src')]))
    assert state['source']['revision'] == plan['runtime'] and not state['source']['mismatches']
    jobs = [('fp8', Path(plan['candidates'][0]['model']), 'fp8-source-provider-inventory.json'), ('nvfp4', Path(plan['candidates'][1]['model']), 'nvfp4-release-inventory.json')]
    for name, model, inventory_name in jobs:
        inventory = json.loads((prior / inventory_name).read_text())
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            sizes = list(pool.map(verify, [(model, x) for x in inventory['files']]))
        state['checkpoints'][name] = {'model': str(model), 'files': len(sizes), 'bytes': sum(sizes), 'inventory_sha256': digest(prior / inventory_name)}
        (root / 'preparation-progress.json').write_text(json.dumps(state, indent=2))
    metadata = json.loads((prior / 'analysis/fp8-metadata-verification.json').read_text())
    for record in metadata['files']:
        assert digest(Path(metadata['model']) / record['file']) == record['expected'], record['file']
    state['fp8_metadata'] = metadata
    env = dict(os.environ, **plan['environment'])
    env['PATH'] = '/root/.cargo/bin:' + env['PATH']
    for key in list(env):
        if key.startswith('SGLANG_SIMULATE_ACC_') or key == 'SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND':
            env.pop(key)
    code = 'from sglang.srt.mem_cache.rust_tree_core.extension import bindings; print(bindings.__file__)'
    with (root / 'rust-build.log').open('wb') as log:
        path = subprocess.check_output(['/opt/sglang/bin/python', '-c', code], env=env, stderr=log, timeout=600).decode().strip().splitlines()[-1]
    state['rust_extension'] = {'path': path, 'sha256': digest(Path(path))}
    state['status'] = 'passed'
except BaseException as error:
    state['status'] = 'failed'
    state['error'] = repr(error)
    raise
finally:
    state['finished'] = time.time()
    (root / 'preparation.json').write_text(json.dumps(state, indent=2))
