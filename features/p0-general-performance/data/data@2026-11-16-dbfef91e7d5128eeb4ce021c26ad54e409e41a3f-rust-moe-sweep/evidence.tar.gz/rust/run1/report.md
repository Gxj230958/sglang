# Serve sweep report

Recommended: `tp4-auto-fp8`

## tp4-deepgemm

Best level: `16`; metrics: `{'cache_hit': 0.7396, 'cached': 679744, 'duration_s': 38.736266758991405, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 919089, 'interactivity_p90': 34.03537136137493, 'level': 16.0, 'ok': 256, 'ok_ratio': 1.0, 'output': 32768, 'output_tps': 422.9649898179453, 'sent': 256, 'total_tps': 12286.443351321228, 'total_tps_per_gpu': 3071.610837830307, 'ttft_p50': 1.1641570491483435, 'ttft_p90': 1.4918722498463466}`
Valid points: 5

## tp4-auto

Best level: `32`; metrics: `{'cache_hit': 0.7711, 'cached': 1417344, 'duration_s': 46.67815579962917, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838080, 'interactivity_p90': 32.02766742306875, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 702.0521510281687, 'sent': 512, 'total_tps': 20392.422571357558, 'total_tps_per_gpu': 5098.1056428393895, 'ttft_p50': 1.850564134074375, 'ttft_p90': 2.3061964580556378}`
Valid points: 6

## tp4-deepgemm-mtp

Best level: `4`; metrics: `{'accept_length': 2.523368559287481, 'cache_hit': 0.74995, 'cached': 344640, 'duration_s': 43.47819681838155, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 459565, 'interactivity_p90': 35.264122129702486, 'level': 4.0, 'ok': 128, 'ok_ratio': 1.0, 'output': 16384, 'output_tps': 188.42940457877938, 'sent': 128, 'total_tps': 5473.803569888469, 'total_tps_per_gpu': 1368.4508924721172, 'ttft_p50': 0.37989626196213067, 'ttft_p90': 0.6901280929567293}`
Valid points: 3

## tp4-auto-mtp

Best level: `4`; metrics: `{'accept_length': 2.594274165485449, 'cache_hit': 0.75565, 'cached': 347264, 'duration_s': 40.195472713094205, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 459560, 'interactivity_p90': 44.31253791480354, 'level': 4.0, 'ok': 128, 'ok_ratio': 1.0, 'output': 16384, 'output_tps': 203.81144074921679, 'sent': 128, 'total_tps': 5920.58362894769, 'total_tps_per_gpu': 1480.1459072369225, 'ttft_p50': 0.40485283348243684, 'ttft_p90': 0.7575620654737577}`
Valid points: 3

## tp4-auto-fp8

Best level: `32`; metrics: `{'cache_hit': 0.77085, 'cached': 1416960, 'duration_s': 45.2307249980513, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838155, 'interactivity_p90': 32.488999498928806, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 724.4729081632461, 'sent': 512, 'total_tps': 21044.504829425794, 'total_tps_per_gpu': 5261.1262073564485, 'ttft_p50': 1.7243903888156638, 'ttft_p90': 2.150347304297611}`
Valid points: 6

## tp4-auto-fp8-mtp

Best level: `4`; metrics: `{'accept_length': 2.4943680984372967, 'cache_hit': 0.74715, 'cached': 343360, 'duration_s': 42.21426957426593, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 459554, 'interactivity_p90': 42.45663022019667, 'level': 4.0, 'ok': 128, 'ok_ratio': 1.0, 'output': 16384, 'output_tps': 194.1715947309744, 'sent': 128, 'total_tps': 5640.484430478352, 'total_tps_per_gpu': 1410.121107619588, 'ttft_p50': 0.4258818360976875, 'ttft_p90': 0.7754469602601604}`
Valid points: 3
