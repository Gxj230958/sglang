# Serve sweep report

Recommended: `tp4-default-mtp`

## tp4-default-mtp

Best level: `1`; metrics: `{'accept_length': 2.455654761904762, 'cache_hit': 0.7798999999999999, 'cached': 179200, 'duration_s': 87.93650852306746, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 0, 'interactivity_p90': 98.57993141183059, 'level': 1, 'ok': 64, 'ok_ratio': 1.0, 'output': 8192, 'output_tps': 93.15812212229325, 'sent': 64, 'total_tps': 93.15812212229325, 'total_tps_per_gpu': 23.289530530573312, 'ttft_p50': 0.3456724935094826, 'ttft_p90': 0.35406696537975224}`
Valid points: 1
