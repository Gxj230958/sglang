# Serve sweep report

Recommended: `tp4-default-mtp`

## tp4-default-mtp

Best level: `1`; metrics: `{'accept_length': 2.4321148459383752, 'cache_hit': 0.7802, 'cached': 358528, 'duration_s': 88.47239764651749, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 459525, 'interactivity_p90': 98.60035166274872, 'level': 1.0, 'ok': 128, 'ok_ratio': 1.0, 'output': 16384, 'output_tps': 92.59395053929661, 'sent': 128, 'total_tps': 2689.593217254659, 'total_tps_per_gpu': 672.3983043136648, 'ttft_p50': 0.3477979212475475, 'ttft_p90': 0.356217054015724}`
Valid points: 1

## tp4-default

Valid points: 0

## tp4-trt-bf16-mtp

Valid points: 0

## tp4-trt-fp8-mtp

Valid points: 0

## dep4-trt-fp8-mtp

Valid points: 0

## dep4-trt-fp8

Valid points: 0

## dep4-trt-fp8-mtp-full

Valid points: 0

## tp4-default-mtp-full

Valid points: 0
