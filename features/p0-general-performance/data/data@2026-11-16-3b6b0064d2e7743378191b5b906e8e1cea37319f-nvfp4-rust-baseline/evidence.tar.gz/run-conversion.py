from pathlib import Path
import subprocess,os,json,time
root=Path("/scratch/codex-glm5lp-nvfp4-perf")
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES="0",PYTHONPATH=str(root/"modelopt"),PYTHONNOUSERSITE="1",OMP_NUM_THREADS="8")
cmd=["python3","-u",str(root/"convert.py"),"--source","/scratch/models/GLM-5-1028-Provider","--output","/scratch/models/GLM-5-1028-Provider-NVFP4-perf","--evidence",str(root/"evidence")]
(root/"conversion-command.json").write_text(json.dumps({"argv":cmd,"environment":{k:env[k] for k in ["CUDA_VISIBLE_DEVICES","PYTHONPATH","PYTHONNOUSERSITE","OMP_NUM_THREADS"]}},indent=2))
started=time.time();rc=subprocess.call(cmd,env=env)
(root/"conversion-status.json").write_text(json.dumps({"exit_code":rc,"elapsed_s":time.time()-started}))
raise SystemExit(rc)
