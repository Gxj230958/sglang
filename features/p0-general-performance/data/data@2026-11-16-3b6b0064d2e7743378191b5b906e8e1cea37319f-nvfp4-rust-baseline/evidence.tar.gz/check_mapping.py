import json
from pathlib import Path

from sglang.srt.configs.glm_loop import GlmLoopConfig, resolve_glm_loop_layout
from sglang.srt.layers.quantization.modelopt_quant import ModelOptMixedPrecisionConfig
from sglang.srt.models.glm_loop import GlmLoopForConditionalGeneration, expand_glm_loop_quantization

root = Path("/scratch/codex-glm5lp-nvfp4-perf")
source = Path("/scratch/models/GLM-5-1028-Provider")
config = GlmLoopConfig.from_dict(json.loads((source / "config.json").read_text()))
layout = resolve_glm_loop_layout(config)
layers = {}
for layer in range(3, 79):
    for projection in ["gate_proj", "up_proj", "down_proj"]:
        layers[f"model.language_model.layers.{layer}.mlp.experts.0.{projection}"] = {
            "quant_algo": "FP8_PB_WO" if layer == 78 else "NVFP4",
            "group_size": 128 if layer == 78 else 16,
        }
    layers[f"model.language_model.layers.{layer}.self_attn.kv_b_proj"] = {"quant_algo": "FP8_PB_WO", "group_size": 128}
original = ModelOptMixedPrecisionConfig.from_config({"quant_algo": "MIXED_PRECISION", "quantized_layers": layers, "ignore": []})
original.apply_weight_name_mapper(GlmLoopForConditionalGeneration.hf_to_sglang_mapper)
before = dict(original.quantized_layers)
mapped = expand_glm_loop_quantization(original, layout)
for slot in range(3, 106):
    assert mapped.resolve_quant_algo(f"model.layers.{slot}.mlp.experts") == "NVFP4", slot
    assert mapped.resolve_quant_algo(f"model.layers.{slot}.self_attn.kv_b_proj") == "FP8_PB_WO", slot
assert mapped.resolve_quant_algo("model.layers.106.mlp.experts") is None
assert original.quantized_layers == before
assert mapped is not original
assert expand_glm_loop_quantization(None, layout) is None
assert original.resolve_quant_algo("model.layers.78.mlp.experts") == "FP8_PB_WO"
assert original.resolve_quant_algo("model.layers.105.mlp.experts") is None
report = {"status": "passed", "physical_layers": layout.physical_layers, "effective_layers": layout.effective_layers, "checked_sparse_execution_slots": 103, "base_mismatch_examples": [78, 105], "source_config_unchanged": True}
(root / "mapping-check.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report))
