import hashlib
import json
import os
import shutil
import subprocess
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from huggingface_hub import HfApi, hf_hub_download
from _common import checkpoint_files, sha256_file

ROOT = Path('/scratch/codex-glm5lp-nvfp4-perf')
MODEL = Path('/scratch/models/GLM-5-1028-Provider-NVFP4-perf')
REPO = 'RadixArk/GLM-5-1028-Provider-NVFP4-perf'


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def inventory():
    def one(path):
        return {'name': str(path.relative_to(MODEL)), 'size': path.stat().st_size, 'sha256': sha256_file(path)}
    with ThreadPoolExecutor(max_workers=4) as executor:
        files = list(executor.map(one, checkpoint_files(MODEL)))
    result = {'file_count': len(files), 'files': files, 'total_file_bytes': sum(x['size'] for x in files)}
    write(ROOT / 'release-inventory.json', result)
    return result


def main():
    token = os.environ.pop('RDXA_HF_TOKEN')
    api = HfApi(token=token)
    if not api.model_info(REPO).private:
        raise RuntimeError('destination privacy check failed')
    if json.loads((ROOT / 'audit-status.json').read_text())['exit_code'] != 0:
        raise RuntimeError('checkpoint audit did not pass')
    sanity = sorted((ROOT / 'runs').glob('sanity-*/status.json'))
    if not any(json.loads(path.read_text())['status'] == 'passed' and json.loads((path.parent / 'tree-core.json').read_text())['selected'] == 'rust' for path in sanity):
        raise RuntimeError('sanity run did not pass')
    provenance = MODEL / 'conversion'
    provenance.mkdir(exist_ok=True)
    for name in ['convert.py', 'audit.py', '_common.py', 'conversion-manifest.json', 'conversion-command.json', 'source-provider-inventory.json', 'runtime.patch', 'runtime-tree-verification.json']:
        shutil.copy2(ROOT / name, provenance / name)
    for name in ['tensor-audit.json', 'real-weight-preflight.json']:
        shutil.copy2(ROOT / 'evidence' / name, provenance / name)
    result = json.loads((ROOT / 'evidence/conversion-result.json').read_text())
    write(provenance / 'conversion-summary.json', {k: v for k, v in result.items() if k not in ['source_inventory', 'output_inventory', 'shard_audits']})
    command = json.loads((ROOT / 'conversion-command.json').read_text())
    script_hash = hashlib.sha256((ROOT / 'convert.py').read_bytes()).hexdigest()
    import shlex
    command_text = ' '.join(f'{key}={shlex.quote(value)}' for key, value in command['environment'].items()) + ' ' + shlex.join(command['argv'])
    card = f'''---
library_name: sglang
pipeline_tag: text-generation
---
# GLM-5-1028-Provider NVFP4 performance checkpoint

This checkpoint is for **performance testing only**. It is derived from the block-FP8 checkpoint by dequantization and requantization. Accuracy is **not validated**. A small text-generation sanity evaluation does not establish quality parity or production suitability.

The 57,600 routed-expert gate, up, and down projections in physical language layers 3–77 are NVFP4: packed E2M1 weights, E4M3 scales per 16 elements, and FP32 global scales. Gate/up projections share each expert's global scale. Conversion applies the source 128×128 FP8 block scales in FP32, rounds the result to BF16, and uses NVIDIA Model Optimizer absmax NVFP4 rounding. The stored activation scale is 1; use dynamic per-token activation quantization in the serving recipe.

The remaining 1,444 block-FP8 weight bases retain their original representation and values. These include attention, shared experts, dense MLPs where present, and the physical layer-78 NextN/MTP head. Tensors outside the converted expert weights and their source block scales are preserved byte-for-byte, including the vision tower, router, normalization, embeddings, and LM head. The converted experts receive the NVFP4 scales described above. The tensor audit in `conversion/tensor-audit.json` records exact coverage and byte equality.

The source weight files match private `RadixArk/GLM-5-1028-Provider` revision `9c24449260e89d2d2bb6ed8f92d5f386c04ad7ff`. Local serving configuration and tokenizer hashes are recorded separately in the conversion manifest. The source is unchanged.

## Reproduction

NVIDIA Model Optimizer v0.46.0 commit: `43fd41a58d52c4e6e5dec1d1ff5989ecc737ae1a`.
Converter SHA256: `{script_hash}`; source is included as `conversion/convert.py`.
SGLang base: `dbfef91e7d5128eeb4ce021c26ad54e409e41a3f`.
SGLang serving commit: `3b6b0064d2e7743378191b5b906e8e1cea37319f` on `perf/glm5lp-nvfp4`; the patch is included as `conversion/runtime.patch`.
The serving patch expands the mixed-precision map into the loop execution slots. FlashInfer 0.7.4 with its CUDA 13.0 sm103a cache was used on GB300.

The exact conversion invocation was:

```bash
{command_text}
```

Run the same invocation with `--preflight` first. The converter expects `source-provider-inventory.json` beside the evidence directory, as supplied here. Its output path must not exist. Conversion used exactly one visible GB300 GPU; no calibration dataset was used.

Serve with `SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND=rust`, `SGLANG_RUST_BUILD_MODE=auto`, `SGLANG_FLASHINFER_NVFP4_PER_TOKEN_ACTIVATION=1`, TP4, `--moe-runner-backend flashinfer_trtllm --disable-shared-experts-fusion`, and the included runtime patch. The FP8 NextN head is preserved; the measured MTP deployment uses the original FP8 source as the explicitly FP8 draft model. Performance measurements pin simulated acceptance to 3.5; ordinary text sanity uses normal decoding. Simulated acceptance results measure runtime speed, not draft quality.
'''
    (MODEL / 'README.md').write_text(card)
    attributes = Path(hf_hub_download(REPO, '.gitattributes', token=token))
    shutil.copy2(attributes, MODEL / '.gitattributes')
    frozen = inventory()
    write(ROOT / 'upload-progress.json', {'state': 'uploading', 'repo_id': REPO, 'private': True, 'files': frozen['file_count'], 'bytes': frozen['total_file_bytes'], 'start': time.time()})
    api.upload_large_folder(repo_id=REPO, repo_type='model', folder_path=MODEL, num_workers=4)
    info = api.model_info(REPO, files_metadata=True)
    if not info.private:
        raise RuntimeError('destination privacy changed')
    actual_attributes = Path(hf_hub_download(REPO, '.gitattributes', revision=info.sha, token=token, force_download=True)).read_bytes()
    if actual_attributes != (MODEL / '.gitattributes').read_bytes():
        original = (MODEL / '.gitattributes').read_text().splitlines()
        actual = actual_attributes.decode().splitlines()
        additions = [line for line in actual if line not in original]
        if any('filter=lfs' not in line or 'diff=lfs' not in line or 'merge=lfs' not in line for line in additions):
            raise RuntimeError('unexpected .gitattributes normalization')
        (MODEL / '.gitattributes').write_bytes(actual_attributes)
        for item in frozen['files']:
            if item['name'] == '.gitattributes':
                item.update(size=len(actual_attributes), sha256=hashlib.sha256(actual_attributes).hexdigest())
        frozen['total_file_bytes'] = sum(item['size'] for item in frozen['files'])
        write(ROOT / 'release-inventory.json', frozen)
    subprocess.run(['python3', str(ROOT / 'verify_hf.py'), REPO, str(ROOT / 'release-inventory.json'), '--revision', info.sha, '--visibility', 'private', '--output', str(ROOT / 'hf-verification.json')], input=token + '\n', text=True, check=True)
    write(ROOT / 'upload-progress.json', {'state': 'verified', 'repo_id': REPO, 'private': True, 'commit': info.sha, 'end': time.time()})


if __name__ == '__main__':
    result = {'start': time.time()}
    try:
        main()
        result['status'] = 'passed'
    except BaseException as error:
        result.update(status='failed', error=repr(error), traceback=traceback.format_exc())
        print(result['traceback'], flush=True)
    result['end'] = time.time()
    write(ROOT / 'upload-status.json', result)
    print(json.dumps(result), flush=True)
