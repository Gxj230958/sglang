import json
import subprocess
import time
from pathlib import Path

root = Path('/scratch/codex-glm5lp-nvfp4-perf')
while not (root / 'monitor.stop').exists():
    value = {'time': time.time()}
    for name in ['memory.events', 'memory.current', 'memory.peak']:
        path = Path('/sys/fs/cgroup') / name
        if path.exists():
            value[name] = path.read_text()
    value['gpu'] = subprocess.check_output(['nvidia-smi', '--query-gpu=index,memory.used,memory.free,utilization.gpu', '--format=csv,noheader,nounits'], text=True)
    with (root / 'resource-monitor.jsonl').open('a') as output:
        output.write(json.dumps(value) + '\n')
    time.sleep(30)
