import argparse
import json
import os
import signal
import socket
import subprocess
import time
import traceback
import urllib.request
from pathlib import Path

ROOT = Path('/scratch/codex-glm5lp-nvfp4-perf')
SOURCE = '/scratch/models/GLM-5-1028-Provider'
CANDIDATE = SOURCE + '-NVFP4-perf'
PORT = 31940
URL = f'http://127.0.0.1:{PORT}'
ENV = dict(os.environ, PYTHONNOUSERSITE='1', CUDA_VISIBLE_DEVICES='0,1,2,3', OMP_NUM_THREADS='4', PYTHONPATH=f'{ROOT}/fi074:/scratch/cc-regate2/overlay:/scratch/kimi-glm42-repro/packages:{ROOT}/src/python', SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND='rust', SGLANG_RUST_BUILD_MODE='auto', CARGO_BUILD_JOBS='4', SGLANG_FLASHINFER_NVFP4_PER_TOKEN_ACTIVATION='1')
for key in list(ENV):
    if key.startswith('SGLANG_SIMULATE_ACC_'):
        del ENV[key]


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def request(path, body=None, timeout=20):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(URL + path, data=data, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return response.read().decode()


def gpu_snapshot():
    cmd = ['nvidia-smi', '--query-gpu=index,name,memory.total,memory.used,memory.free,utilization.gpu', '--format=csv,noheader,nounits']
    return subprocess.check_output(cmd, text=True)


def idle_check(folder):
    snapshot = gpu_snapshot()
    (folder / 'gpu-before.csv').write_text(snapshot)
    apps = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,process_name,used_memory', '--format=csv,noheader'], text=True).strip()
    (folder / 'gpu-processes-before.txt').write_text(apps)
    if apps or any(float(line.split(',')[3]) > 1000 or float(line.split(',')[5]) > 0 for line in snapshot.splitlines()):
        raise RuntimeError('GPUs are not idle; refusing launch')
    for port in [PORT, PORT + 1]:
        with socket.socket() as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(('127.0.0.1', port))


def wait_audit():
    deadline = time.monotonic() + 7200
    while time.monotonic() < deadline:
        path = ROOT / 'audit-status.json'
        if path.exists():
            result = json.loads(path.read_text())
            if result['exit_code'] != 0:
                raise RuntimeError(f'checkpoint audit failed: {result}')
            return
        time.sleep(10)
    raise TimeoutError('checkpoint audit deadline')


def stop(process):
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=30)
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait(timeout=10)


def launch(folder, model, mtp):
    idle_check(folder)
    env = ENV.copy()
    if mtp:
        env.update(SGLANG_SIMULATE_ACC_LEN='3.5', SGLANG_SIMULATE_ACC_METHOD='match-expected', SGLANG_SIMULATE_ACC_TOKEN_MODE='real-draft-token')
    cmd = ['python3', '-m', 'sglang.launch_server', '--model-path', model, '--host', '127.0.0.1', '--port', str(PORT), '--dist-init-addr', f'127.0.0.1:{PORT + 1}', '--tp-size', '4', '--moe-runner-backend', 'flashinfer_trtllm', '--disable-shared-experts-fusion', '--dsa-prefill-backend', 'flashmla_sparse', '--dsa-decode-backend', 'flashmla_sparse', '--kv-cache-dtype', 'bf16', '--mem-fraction-static', '0.80', '--context-length', '32768', '--max-running-requests', '64', '--cuda-graph-max-bs-decode', '64', '--disable-prefill-cuda-graph', '--chunked-prefill-size', '8192', '--enable-fp32-lm-head', '--reasoning-parser', 'glm45', '--tool-call-parser', 'glm47', '--enable-cache-report', '--enable-metrics', '--random-seed', '1']
    if mtp:
        cmd += ['--speculative-algorithm', 'EAGLE', '--speculative-num-steps', '3', '--speculative-eagle-topk', '1', '--speculative-num-draft-tokens', '4', '--speculative-draft-model-path', SOURCE, '--speculative-draft-model-quantization', 'fp8']
    write(folder / 'launch.json', {'command': cmd, 'environment': {k: v for k, v in env.items() if k.startswith(('SGLANG_', 'CUDA_')) or k in ('PYTHONPATH', 'PYTHONNOUSERSITE', 'OMP_NUM_THREADS')}, 'time': time.time(), 'runtime_commit': '3b6b0064d2e7743378191b5b906e8e1cea37319f'})
    log = (folder / 'server.log').open('wb')
    process = subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True, cwd=ROOT / 'src')
    write(folder / 'server-process.json', {'pid': process.pid, 'pgid': process.pid})
    try:
        deadline = time.monotonic() + 1800
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise RuntimeError(f'server exited {process.returncode}')
            try:
                request('/health', timeout=3)
                (folder / 'server-info-ready.json').write_text(request('/server_info'))
                (folder / 'gpu-ready.csv').write_text(gpu_snapshot())
                core_lines = [line for line in (folder / 'server.log').read_text().splitlines() if 'Tree Core:' in line]
                if not core_lines or any('Tree Core: RustUnifiedTreeCore' not in line for line in core_lines):
                    raise RuntimeError(f'Rust tree core selection failed: {core_lines}')
                write(folder / 'tree-core.json', {'selected': 'rust', 'evidence': core_lines})
                return process
            except (OSError, TimeoutError):
                time.sleep(5)
        raise TimeoutError('server startup deadline')
    except BaseException:
        stop(process)
        raise


def run_command(folder, name, cmd, env, timeout):
    write(folder / f'{name}-command.json', cmd)
    with (folder / f'{name}.log').open('wb') as log:
        result = subprocess.run(cmd, env=env, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
    if result.returncode:
        raise RuntimeError(f'{name} exited {result.returncode}')


def sanity(folder, model):
    outputs = []
    for prompt in ['Reply with the word hello.', 'What is 17 plus 25? Answer in one short sentence.', 'Explain in two sentences why ice floats on water.']:
        body = {'model': model, 'messages': [{'role': 'user', 'content': prompt}], 'temperature': 1.0, 'top_p': 0.95, 'max_tokens': 1024, 'chat_template_kwargs': {'enable_thinking': False, 'thinking': False}}
        result = json.loads(request('/v1/chat/completions', body, timeout=300))
        outputs.append({'prompt': prompt, 'response': result})
        write(folder / 'chat.json', outputs)
        choice = result['choices'][0]
        if choice['finish_reason'] != 'stop' or not choice['message'].get('content'):
            raise RuntimeError('chat did not return nonempty content and stop normally')
    env = dict(os.environ, PYTHONPATH=str(ROOT / 'eval-deps'), PYTHONNOUSERSITE='1', CUDA_VISIBLE_DEVICES='', OPENAI_API_KEY='dummy')
    cmd = [str(ROOT / 'eval-deps/bin/sgl-eval'), 'run', 'gsm8k', '--base-url', URL + '/v1', '--model', model, '--num-examples', '100', '--num-threads', '16', '--temperature', '1.0', '--top-p', '0.95', '--max-tokens', '8192', '--seed', '1', '--out-dir', str(folder / 'gsm8k')]
    run_command(folder, 'gsm8k', cmd, env, 3600)


def benchmark(folder, model, mtp):
    shapes = [(2000, 500, 1), (2000, 500, 8), (2000, 500, 32), (30000, 300, 4)] if mtp else [(2000, 500, 1), (2000, 500, 32)]
    for length, output, concurrency in shapes:
        for seed in [1, 2]:
            name = f'bench-i{length}-o{output}-c{concurrency}-s{seed}'
            count = max(16, concurrency * 4)
            cmd = ['python3', '-m', 'sglang.benchmark.serving', '--backend', 'sglang', '--base-url', URL, '--model', model, '--tokenizer', SOURCE, '--dataset-name', 'random-ids', '--tokenize-prompt', '--random-input-len', str(length), '--random-output-len', str(output), '--random-range-ratio', '1', '--num-prompts', str(count), '--max-concurrency', str(concurrency), '--seed', str(seed), '--flush-cache', '--warmup-requests', '2', '--output-file', str(folder / f'{name}.jsonl'), '--output-details']
            (folder / f'{name}-info-before.json').write_text(request('/server_info'))
            run_command(folder, name, cmd, ENV, 2400)
            (folder / f'{name}-info-after.json').write_text(request('/server_info'))
            (folder / f'{name}-metrics.txt').write_text(request('/metrics'))
            (folder / f'{name}-gpu.csv').write_text(gpu_snapshot())
            rows = [json.loads(line) for line in (folder / f'{name}.jsonl').read_text().splitlines()]
            row = rows[-1]
            if row['completed'] != count or row['total_output_tokens'] != count * output or row['total_input_tokens'] != count * length:
                raise RuntimeError(f'benchmark incomplete: {name}')
            if mtp and (row.get('accept_length') is None or abs(row['accept_length'] - 3.5) > 0.12):
                raise RuntimeError(f'acceptance outside tolerance: {name}: {row.get("accept_length")}')
            print(json.dumps({'point': name, 'output_throughput': row['output_throughput'], 'accept_length': row.get('accept_length')}), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', choices=['sanity', 'nvfp4-mtp', 'nvfp4-off', 'fp8-mtp', 'fp8-off'], required=True)
    parser.add_argument('--attempt', default='1')
    args = parser.parse_args()
    folder = ROOT / 'runs' / f'{args.job}-{args.attempt}'
    folder.mkdir(parents=True, exist_ok=False)
    process = None
    result = {'job': args.job, 'start': time.time()}
    try:
        wait_audit()
        if json.loads((ROOT / 'rust-build-status.json').read_text())['exit_code'] != 0:
            raise RuntimeError('Rust extension build did not pass')
        model = SOURCE if args.job.startswith('fp8') else CANDIDATE
        mtp = args.job.endswith('-mtp')
        process = launch(folder, model, mtp)
        if args.job == 'sanity':
            sanity(folder, model)
        else:
            benchmark(folder, model, mtp)
        result['status'] = 'passed'
    except BaseException as error:
        result.update(status='failed', error=repr(error), traceback=traceback.format_exc())
        print(result['traceback'], flush=True)
    finally:
        if process is not None:
            stop(process)
        result['end'] = time.time()
        write(folder / 'status.json', result)
        time.sleep(5)
        (folder / 'gpu-final.csv').write_text(gpu_snapshot())
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
