from pathlib import Path
import json,os,subprocess,time
r=Path('/scratch/codex-glm5lp-nvfp4-perf')
env=dict(os.environ,PYTHONPATH=str(r/'fi074')+':/scratch/cc-regate2/overlay:/scratch/kimi-glm42-repro/packages:'+str(r/'src/python'),PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='',SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND='rust',SGLANG_RUST_BUILD_MODE='auto',CARGO_BUILD_JOBS='4')
started=time.time()
versions={cmd:subprocess.check_output([cmd,'--version'],cwd=r/'src/rust',env=env,text=True).strip() for cmd in ['cargo','rustc']}
(r/'rust-toolchain.json').write_text(json.dumps(versions,indent=2))
code="from sglang.srt.mem_cache.rust_tree_core.extension import bindings; import json; print(json.dumps({'extension':bindings.__file__,'status':'loaded'}))"
rc=subprocess.call(['python3','-u','-c',code],cwd=r/'src',env=env)
(r/'rust-build-status.json').write_text(json.dumps({'exit_code':rc,'elapsed_s':time.time()-started,'toolchain':versions},indent=2))
raise SystemExit(rc)
