import json
import re
from pathlib import Path

root = Path('/scratch/codex-glm5lp-nvfp4-perf')
result = {}
for name in ['conversion-status.json', 'audit-status.json', 'runtime-tree-verification.json', 'upload-status.json', 'upload-progress.json', 'hf-verification.json', 'rust-build-status.json', 'rust-toolchain.json']:
    if (root / name).exists():
        result[name] = json.loads((root / name).read_text())
for name in ['conversion-result.json', 'tensor-audit.json', 'real-weight-preflight.json']:
    if (root / 'evidence' / name).exists():
        value = json.loads((root / 'evidence' / name).read_text())
        result[name] = {k: v for k, v in value.items() if k not in ['source_inventory', 'output_inventory', 'shard_audits']}
runs = {}
for folder in sorted((root / 'runs').glob('*')):
    if not folder.is_dir():
        continue
    entry = {}
    for name in ['status.json', 'launch.json', 'chat.json', 'server-info-ready.json', 'tree-core.json']:
        if (folder / name).exists():
            value = json.loads((folder / name).read_text())
            if name == 'server-info-ready.json':
                value = {key: value.get(key) for key in ['internal_states', 'server_args', 'version']}
            entry[name] = value
    for name in ['gpu-before.csv', 'gpu-ready.csv', 'gpu-final.csv']:
        if (folder / name).exists():
            entry[name] = (folder / name).read_text()
    if (folder / 'server.log').exists():
        lines = (folder / 'server.log').read_text(errors='replace').splitlines()
        entry['memory_lines'] = [line for line in lines if re.search(r'(KV Cache|KV cache|memory pool|max_total_num_tokens=|Load weight end|Load weights end|available_gpu_mem|mem usage=)', line)][:120]
        entry['error_lines'] = [line for line in lines if re.search(r'(Traceback|Error:|Exception:|NaN|nan detected)', line)][-40:]
    entry['benchmarks'] = []
    for path in sorted(folder.glob('bench-*.jsonl')):
        row = json.loads(path.read_text().splitlines()[-1])
        fields = ['duration', 'completed', 'total_input_tokens', 'total_output_tokens', 'output_throughput', 'mean_ttft_ms', 'mean_tpot_ms', 'mean_itl_ms', 'p99_ttft_ms', 'p99_itl_ms', 'accept_length', 'max_concurrency', 'random_input_len', 'random_output_len']
        entry['benchmarks'].append(dict(file=path.name, **{key: row.get(key) for key in fields}))
    entry['gsm8k'] = [dict(path=str(path), metrics=json.loads(path.read_text())) for path in sorted(folder.glob('gsm8k/*/metrics.json'))]
    runs[folder.name] = entry
result['runs'] = runs
(root / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'runs'}, indent=2))
print('runs', [(name, item.get('status.json', {}).get('status', 'running'), len(item.get('benchmarks', []))) for name, item in runs.items()])
