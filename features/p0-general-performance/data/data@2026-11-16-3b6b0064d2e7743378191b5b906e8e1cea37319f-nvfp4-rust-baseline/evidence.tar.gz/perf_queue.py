import json
import subprocess
import time
from pathlib import Path

root = Path('/scratch/codex-glm5lp-nvfp4-perf')
result = {'start': time.time(), 'jobs': []}
for job in ['nvfp4-mtp', 'fp8-mtp', 'nvfp4-off', 'fp8-off']:
    with (root / f'{job}-runner.log').open('wb') as log:
        process = subprocess.run(['python3', str(root / 'runner.py'), '--job', job, '--attempt', 'rust1'], stdout=log, stderr=subprocess.STDOUT)
    path = root / 'runs' / (job + '-rust1') / 'status.json'
    status = json.loads(path.read_text()) if path.exists() else {'status': 'failed', 'error': f'runner exit {process.returncode}'}
    result['jobs'].append({'job': job, 'status': status})
    (root / 'perf-queue-progress.json').write_text(json.dumps(result, indent=2) + '\n')
    if status['status'] != 'passed':
        result.update(status='failed', failed_job=job)
        break
else:
    result['status'] = 'passed'
result['end'] = time.time()
(root / 'perf-queue-status.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
