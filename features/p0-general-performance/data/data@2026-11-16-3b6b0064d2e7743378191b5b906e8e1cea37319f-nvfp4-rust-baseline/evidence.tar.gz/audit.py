import hashlib
import json
import re
import time
from collections import Counter
from functools import lru_cache
from pathlib import Path

import torch
from safetensors import safe_open

from _common import checkpoint_layout, tensor_chunks, tensor_bytes


@lru_cache(maxsize=4)
def open_shard(path):
    return safe_open(path, framework="pt", device="cpu")


def read_scalar(root, layout, key):
    return open_shard(root / layout["weight_map"][key]).get_tensor(key).item()


def scan_positive_finite(root, filename, key, rows_per_chunk):
    value = open_shard(root / filename).get_tensor(key).float()
    if not torch.isfinite(value).all() or not (value > 0).all():
        raise ValueError(f"invalid scale: {key}")
    return value.numel(), value.min().item(), value.max().item()


def compare_tensor_content(source_root, source_file, output_root, output_file, key, rows_per_chunk):
    source = tensor_chunks(source_root, source_file, key, rows_per_chunk)
    output = tensor_chunks(output_root, output_file, key, rows_per_chunk)
    for first, second in zip(source, output, strict=True):
        if not torch.equal(first.contiguous().reshape(-1).view(torch.uint8), second.contiguous().reshape(-1).view(torch.uint8)):
            raise ValueError(f"preserved tensor bytes differ: {key}")


def main():
    torch.set_num_threads(4)
    root = Path("/scratch/codex-glm5lp-nvfp4-perf")
    source_path = Path("/scratch/models/GLM-5-1028-Provider")
    output_path = Path("/scratch/models/GLM-5-1028-Provider-NVFP4-perf")
    start = time.time()
    manifest = json.loads((root / "conversion-manifest.json").read_text())
    for name, digest in manifest["source_identity"].items():
        if hashlib.sha256((source_path / name).read_bytes()).hexdigest() != digest:
            raise ValueError(f"source identity changed: {name}")
    if hashlib.sha256((root / "convert.py").read_bytes()).hexdigest() != manifest["script_sha256"]:
        raise ValueError("converter identity changed")
    source = checkpoint_layout(source_path)
    output = checkpoint_layout(output_path)
    source_meta, output_meta = source["tensor_metadata"], output["tensor_metadata"]
    for layout in [source, output]:
        total = sum(tensor_bytes(meta["shape"], meta["dtype"]) for meta in layout["tensor_metadata"].values())
        if total != layout["indexed_payload_bytes"]:
            raise ValueError("indexed payload byte count mismatch")
    source_config = json.loads((source_path / "config.json").read_text())
    config = json.loads((output_path / "config.json").read_text())
    quant = json.loads((output_path / "hf_quant_config.json").read_text())["quantization"]
    if config["quantization_config"]["quantized_layers"] != quant["quantized_layers"]:
        raise ValueError("quantized layer metadata mismatch")
    if set(config["quantization_config"]["ignore"]) != set(quant["exclude_modules"]):
        raise ValueError("exclusion metadata mismatch")
    targets = set()
    for key, meta in source_meta.items():
        match = re.fullmatch(r"model\.language_model\.layers\.(\d+)\.mlp\.experts\.(\d+)\.(gate_proj|up_proj|down_proj)\.weight", key)
        if match and int(match[1]) < source_config["text_config"]["num_hidden_layers"]:
            if meta["dtype"] != "F8_E4M3" or len(meta["shape"]) != 2:
                raise ValueError(f"unexpected source form: {key}")
            targets.add(key)
    if len(targets) != 57600:
        raise ValueError(f"target coverage mismatch: {len(targets)}")
    removed = {key + "_scale_inv" for key in targets}
    added = {key.removesuffix(".weight") + suffix for key in targets for suffix in [".weight_scale", ".weight_scale_2", ".input_scale"]}
    expected_keys = (set(source_meta) - removed) | added
    if set(output_meta) != expected_keys:
        raise ValueError("source-derived output key set mismatch")
    if any(key.endswith((".k_scale", ".v_scale")) for key in output_meta):
        raise ValueError("unexpected attention KV scale")
    expected_metadata = {}
    for key in source_meta:
        if key.endswith(".weight_scale_inv"):
            base = key.removesuffix(".weight_scale_inv")
            expected_metadata[base] = {"quant_algo": "NVFP4", "group_size": 16} if base + ".weight" in targets else {"quant_algo": "FP8_PB_WO", "group_size": 128}
    if quant["quantized_layers"] != expected_metadata:
        raise ValueError("precision map differs from source-derived contract")
    count, smallest, largest = 0, float("inf"), 0.0
    global_scales = {}
    for i, key in enumerate(sorted(targets), 1):
        base = key.removesuffix(".weight")
        rows, columns = source_meta[key]["shape"]
        forms = {"weight": ("U8", [rows, columns // 2]), "weight_scale": ("F8_E4M3", [rows, columns // 16]), "weight_scale_2": ("F32", []), "input_scale": ("F32", [])}
        for suffix, (dtype, shape) in forms.items():
            name = base + "." + suffix
            if output_meta[name] != {"dtype": dtype, "shape": shape}:
                raise ValueError(f"packed form mismatch: {name}")
            if "scale" in suffix:
                n, minimum, maximum = scan_positive_finite(output_path, output["weight_map"][name], name, 1024)
                count += n
                smallest, largest = min(smallest, minimum), max(largest, maximum)
        if read_scalar(output_path, output, base + ".input_scale") != 1.0:
            raise ValueError(f"activation scale mismatch: {base}")
        global_scales[base] = read_scalar(output_path, output, base + ".weight_scale_2")
        if i % 3000 == 0:
            print(json.dumps({"audited_nvfp4_bases": i, "elapsed_s": time.time() - start}), flush=True)
    for base, scale in global_scales.items():
        if base.endswith(".gate_proj") and scale != global_scales[base.removesuffix(".gate_proj") + ".up_proj"]:
            raise ValueError(f"gate/up scale mismatch: {base}")
    unchanged = sorted(set(source_meta) - targets - removed)
    unchanged_bytes = 0
    for key in unchanged:
        if source_meta[key] != output_meta[key]:
            raise ValueError(f"preserved metadata mismatch: {key}")
        compare_tensor_content(source_path, source["weight_map"][key], output_path, output["weight_map"][key], key, 1024)
        with safe_open(source_path / source["weight_map"][key], framework="pt", device="cpu") as stream:
            value = stream.get_tensor(key)
            unchanged_bytes += value.numel() * value.element_size()
    preserved = {}
    for name in ["tokenizer.json", "tokenizer_config.json", "generation_config.json", "preprocessor_config.json", "chat_template.jinja"]:
        if (source_path / name).exists():
            a = hashlib.sha256((source_path / name).read_bytes()).hexdigest()
            b = hashlib.sha256((output_path / name).read_bytes()).hexdigest()
            if a != b:
                raise ValueError(f"behavior metadata mismatch: {name}")
            preserved[name] = a
    result = {"status": "passed", "converted_nvfp4_bases": len(targets), "preserved_fp8_bases": len(expected_metadata) - len(targets), "source_tensors": len(source_meta), "output_tensors": len(output_meta), "source_index_physical_equal": True, "output_index_physical_equal": True, "unchanged_tensors": len(unchanged), "unchanged_bytes": unchanged_bytes, "unchanged_content_equal": True, "mtp_tensors_preserved": sum(key.startswith("model.language_model.layers.78.") for key in unchanged), "vision_tensors_preserved": sum("vision" in key or "visual" in key for key in unchanged), "scale_values": count, "scale_minimum": smallest, "scale_maximum": largest, "scale_finite_positive": True, "gate_up_scale_equal": True, "metadata_preserved": preserved, "elapsed_s": time.time() - start, "dtype_counts": dict(Counter(item["dtype"] for item in output_meta.values()))}
    (root / "evidence/tensor-audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
