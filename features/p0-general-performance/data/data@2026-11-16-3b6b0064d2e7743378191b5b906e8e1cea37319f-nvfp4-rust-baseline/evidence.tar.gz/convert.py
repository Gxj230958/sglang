import argparse
import gc
import hashlib
import json
import os
import re
import shutil
import sys
import time
from collections import Counter
from pathlib import Path

import torch
from modelopt.torch.quantization.qtensor.nvfp4_tensor import NVFP4QTensor
from safetensors import safe_open
from safetensors.torch import save_file


def file_hash(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(32 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def tensor_hash(tensor):
    return hashlib.sha256(tensor.contiguous().reshape(-1).view(torch.uint8).numpy().tobytes()).hexdigest()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def selected(key):
    match = re.fullmatch(r"model.language_model.layers.(\d+).mlp.experts.(\d+).(gate_proj|up_proj|down_proj).weight", key)
    return bool(match and 3 <= int(match[1]) < 78)


def read_tensor(source, weight_map, key):
    with safe_open(source / weight_map[key], framework="pt", device="cpu") as stream:
        return stream.get_tensor(key)


def dequantize(source, weight_map, key):
    value = read_tensor(source, weight_map, key).to(device="cuda", dtype=torch.float32)
    scale = read_tensor(source, weight_map, key + "_scale_inv").to("cuda")
    rows, columns = value.shape
    value = value.reshape(rows // 128, 128, columns // 128, 128)
    value = (value * scale[:, None, :, None]).reshape(rows, columns).to(torch.bfloat16)
    if not torch.isfinite(value).all():
        raise ValueError(f"nonfinite dequantized source: {key}")
    return value


def quantize(source, weight_map, key):
    value = dequantize(source, weight_map, key)
    amax = value.abs().amax().float()
    if key.endswith(("gate_proj.weight", "up_proj.weight")):
        other = key.replace("gate_proj.weight", "up_proj.weight") if key.endswith("gate_proj.weight") else key.replace("up_proj.weight", "gate_proj.weight")
        partner = dequantize(source, weight_map, other)
        amax = torch.maximum(amax, partner.abs().amax().float())
        del partner
    global_scale = torch.where(amax > 0, amax / 2688.0, torch.ones_like(amax))
    packed, scales, scale2 = NVFP4QTensor.quantize(value, block_size=16, weights_scaling_factor_2=global_scale)
    if not torch.isfinite(scales.float()).all() or not (scales.float() > 0).all():
        raise ValueError(f"invalid NVFP4 block scales: {key}")
    base = key.removesuffix(".weight")
    result = {
        key: packed._quantized_data.cpu().contiguous(),
        base + ".weight_scale": scales.cpu().contiguous(),
        base + ".weight_scale_2": scale2.cpu().reshape(()),
        base + ".input_scale": torch.tensor(1.0, dtype=torch.float32),
    }
    return result, value, packed, scales, scale2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(8)
    if torch.cuda.device_count() != 1 or os.environ.get("CUDA_VISIBLE_DEVICES") != "0":
        raise RuntimeError("conversion requires CUDA_VISIBLE_DEVICES=0 and one visible GPU")
    args.evidence.mkdir(parents=True, exist_ok=True)
    index = json.loads((args.source / "model.safetensors.index.json").read_text())
    weight_map = index["weight_map"]
    config = json.loads((args.source / "config.json").read_text())
    targets = sorted(key for key in weight_map if selected(key))
    if len(targets) != 75 * 256 * 3:
        raise ValueError(f"unexpected routed target count: {len(targets)}")
    if args.preflight:
        tests = []
        for projection in ["gate_proj", "up_proj", "down_proj"]:
            key = f"model.language_model.layers.3.mlp.experts.0.{projection}.weight"
            result, original, packed, scales, scale2 = quantize(args.source, weight_map, key)
            raw = packed._quantized_data
            codes = torch.stack((raw & 15, raw >> 4), dim=-1).reshape(original.shape)
            table = torch.tensor([0, .5, 1, 1.5, 2, 3, 4, 6, 0, -.5, -1, -1.5, -2, -3, -4, -6], device="cuda")
            recovered = table[codes.long()] * scales.float().repeat_interleave(16, -1) * scale2
            relative_rmse = ((recovered - original.float()).square().mean() / original.float().square().mean()).sqrt().item()
            if not torch.isfinite(recovered).all() or relative_rmse > 0.2:
                raise ValueError(f"failed real-weight preflight: {key}, relative RMSE {relative_rmse}")
            tests.append({"key": key, "relative_rmse": relative_rmse, "scale_min": scales.float().min().item(), "scale_max": scales.float().max().item(), "scale2": scale2.item(), "forms": {k: {"dtype": str(v.dtype), "shape": list(v.shape)} for k, v in result.items()}})
        report = {"status": "passed", "tests": tests, "gpu": torch.cuda.get_device_name(), "peak_allocated_bytes": torch.cuda.max_memory_allocated()}
        write_json(args.evidence / "real-weight-preflight.json", report)
        print(json.dumps(report), flush=True)
        return
    if not (args.evidence / "real-weight-preflight.json").exists():
        raise RuntimeError("real-weight preflight required")
    provider = json.loads((args.evidence.parent / "source-provider-inventory.json").read_text())
    provider_files = {item["name"]: item for item in provider["files"]}
    args.output.mkdir(parents=True, exist_ok=False)
    output_map = {}
    quantized_layers = {}
    for key in weight_map:
        if key.endswith(".weight_scale_inv"):
            base = key.removesuffix(".weight_scale_inv")
            quantized_layers[base] = {"quant_algo": "NVFP4", "group_size": 16} if selected(base + ".weight") else {"quant_algo": "FP8_PB_WO", "group_size": 128}
    exclusions = config["quantization_config"].get("modules_to_not_convert", [])
    quantization = {"quant_algo": "MIXED_PRECISION", "quantized_layers": quantized_layers, "exclude_modules": exclusions, "kv_cache_quant_algo": None}
    config["quantization_config"] = {"quant_method": "modelopt_mixed", "quant_algo": "MIXED_PRECISION", "quantized_layers": quantized_layers, "ignore": exclusions}
    config["performance_testing_only"] = True
    config["conversion_source_quantization"] = "FP8 E4M3 block128 dequantized to BF16 before NVFP4"
    source_inventory = []
    output_inventory = []
    tensor_audits = {}
    total_bytes = 0
    start = time.time()
    for number, filename in enumerate(sorted(set(weight_map.values())), 1):
        source_file = args.source / filename
        source_digest = file_hash(source_file)
        if source_digest != provider_files[filename]["sha256"] or source_file.stat().st_size != provider_files[filename]["size"]:
            raise ValueError(f"source provider identity mismatch: {filename}")
        tensors = {}
        converted = 0
        with safe_open(source_file, framework="pt", device="cpu") as stream:
            for key in stream.keys():
                if key.endswith(".weight_scale_inv") and selected(key.removesuffix("_scale_inv")):
                    continue
                if selected(key):
                    result, value, packed, scales, scale2 = quantize(args.source, weight_map, key)
                    tensors.update(result)
                    del result, value, packed, scales, scale2
                    converted += 1
                else:
                    tensors[key] = stream.get_tensor(key).clone()
        expected = {key: {"sha256": tensor_hash(value), "shape": list(value.shape), "dtype": str(value.dtype)} for key, value in tensors.items()}
        temporary = args.output / (filename + ".tmp")
        save_file(tensors, str(temporary), metadata={"format": "pt"})
        temporary.replace(args.output / filename)
        with safe_open(args.output / filename, framework="pt", device="cpu") as stream:
            if set(stream.keys()) != set(tensors):
                raise ValueError(f"output tensor key mismatch: {filename}")
            for key in stream.keys():
                value = stream.get_tensor(key)
                if tensor_hash(value) != expected[key]["sha256"]:
                    raise ValueError(f"output content mismatch: {key}")
                total_bytes += value.numel() * value.element_size()
                output_map[key] = filename
        output_file = args.output / filename
        source_inventory.append({"name": filename, "size": source_file.stat().st_size, "sha256": source_digest})
        output_inventory.append({"name": filename, "size": output_file.stat().st_size, "sha256": file_hash(output_file)})
        tensor_audits[filename] = {"tensors": len(tensors), "converted_bases": converted, "content_readback_equal": True}
        write_json(args.evidence / (filename + ".tensors.json"), expected)
        write_json(args.evidence / "progress.json", {"shards_complete": number, "shards_total": 142, "elapsed_s": time.time() - start, "source_inventory": source_inventory, "output_inventory": output_inventory, "shard_audits": tensor_audits})
        print(json.dumps({"shard": number, "file": filename, "converted": converted, "elapsed_s": round(time.time() - start, 1)}), flush=True)
        del tensors, expected, value
        gc.collect()
    if sum(x["converted_bases"] for x in tensor_audits.values()) != len(targets):
        raise ValueError("converted count mismatch")
    for file in args.source.iterdir():
        if file.is_file() and file.suffix in {".json", ".jinja", ".txt", ".model"} and file.name not in {"config.json", "model.safetensors.index.json"}:
            shutil.copy2(file, args.output / file.name)
    write_json(args.output / "config.json", config)
    write_json(args.output / "hf_quant_config.json", {"producer": {"name": "modelopt", "version": "0.46.0"}, "quantization": quantization})
    write_json(args.output / "model.safetensors.index.json", {"metadata": {"total_size": total_bytes}, "weight_map": output_map})
    report = {"status": "converted", "converted_bases": len(targets), "preserved_fp8_bases": len(quantized_layers) - len(targets), "tensor_count": len(output_map), "payload_bytes": total_bytes, "elapsed_s": time.time() - start, "peak_gpu_allocated_bytes": torch.cuda.max_memory_allocated(), "source_inventory": source_inventory, "output_inventory": output_inventory, "shard_audits": tensor_audits}
    write_json(args.evidence / "conversion-result.json", report)
    print(json.dumps({k: v for k, v in report.items() if k not in {"source_inventory", "output_inventory", "shard_audits"}}), flush=True)


if __name__ == "__main__":
    main()
