from pathlib import Path
import os,subprocess,json,time
root=Path("/scratch/codex-glm5lp-nvfp4-perf")
for _ in range(360):
 if (root/"conversion-status.json").exists():break
 time.sleep(10)
else:raise RuntimeError("conversion deadline exceeded")
if json.loads((root/"conversion-status.json").read_text())["exit_code"]:raise RuntimeError("conversion failed")
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES="",OMP_NUM_THREADS="4",PYTHONNOUSERSITE="1")
rc=subprocess.call(["python3","-u",str(root/"audit.py")],env=env)
(root/"audit-status.json").write_text(json.dumps({"exit_code":rc}))
raise SystemExit(rc)
