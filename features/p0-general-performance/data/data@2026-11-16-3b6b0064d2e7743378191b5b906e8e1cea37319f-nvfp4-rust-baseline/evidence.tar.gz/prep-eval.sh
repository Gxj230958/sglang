set -e
 git clone --depth 1 https://github.com/sgl-project/sgl-eval.git /scratch/codex-glm5lp-nvfp4-perf/sgl-eval
 python3 -m pip install --target /scratch/codex-glm5lp-nvfp4-perf/eval-deps /scratch/codex-glm5lp-nvfp4-perf/sgl-eval
