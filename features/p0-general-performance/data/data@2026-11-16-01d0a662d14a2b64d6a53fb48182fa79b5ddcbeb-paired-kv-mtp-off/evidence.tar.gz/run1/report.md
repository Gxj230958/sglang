# Serve sweep report

Recommended: `nvfp4-kv-fp8_e4m3-mtp-off`

## fp8-kv-bf16-mtp-off

Best level: `32`; metrics: `{'cache_hit': 0.76975, 'cached': 1414976, 'duration_s': 46.574185820063576, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838134, 'interactivity_p90': 32.10745346619544, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 703.5657140081071, 'sent': 512, 'total_tps': 20436.96506113441, 'total_tps_per_gpu': 5109.241265283603, 'ttft_p50': 1.8575736308121122, 'ttft_p90': 2.3126136317150667}`
Valid points: 6

## nvfp4-kv-bf16-mtp-off

Best level: `32`; metrics: `{'cache_hit': 0.7721, 'cached': 1419264, 'duration_s': 38.379146664985456, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838137, 'interactivity_p90': 41.60555639313863, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 853.7970183874854, 'sent': 512, 'total_tps': 24800.877825283336, 'total_tps_per_gpu': 6200.219456320834, 'ttft_p50': 1.639127978705801, 'ttft_p90': 2.039402784546837}`
Valid points: 6

## fp8-kv-fp8_e4m3-mtp-off

Best level: `32`; metrics: `{'cache_hit': 0.7715, 'cached': 1418112, 'duration_s': 45.097400053055026, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838172, 'interactivity_p90': 32.60242454145764, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 726.6093883606854, 'sent': 512, 'total_tps': 21106.752853926417, 'total_tps_per_gpu': 5276.688213481604, 'ttft_p50': 1.7125078960089013, 'ttft_p90': 2.1374835704336874}`
Valid points: 6

## nvfp4-kv-fp8_e4m3-mtp-off

Best level: `32`; metrics: `{'cache_hit': 0.7718, 'cached': 1418688, 'duration_s': 37.81989233440254, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838175, 'interactivity_p90': 42.60780957910363, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 866.4223501918508, 'sent': 512, 'total_tps': 25168.117654918267, 'total_tps_per_gpu': 6292.029413729567, 'ttft_p50': 1.623596316203475, 'ttft_p90': 2.0186601453460753}`
Valid points: 6
