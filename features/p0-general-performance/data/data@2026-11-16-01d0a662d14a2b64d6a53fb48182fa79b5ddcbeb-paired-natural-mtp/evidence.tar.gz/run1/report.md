# Serve sweep report

Recommended: `nvfp4-kv-bf16-mtp-natural`

## fp8-kv-bf16-mtp-natural

Best level: `4`; metrics: `{'accept_length': 2.5154664422136106, 'cache_hit': 0.7495, 'cached': 344448, 'duration_s': 40.27076586103067, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 459565, 'interactivity_p90': 43.64121265543546, 'level': 4.0, 'ok': 128, 'ok_ratio': 1.0, 'output': 16384, 'output_tps': 203.42524736320763, 'sent': 128, 'total_tps': 5909.4273227896, 'total_tps_per_gpu': 1477.3568306974, 'ttft_p50': 0.4002869972609915, 'ttft_p90': 0.7274073464097455}`
Valid points: 3

## nvfp4-kv-bf16-mtp-natural

Best level: `4`; metrics: `{'accept_length': 2.4308140822421076, 'cache_hit': 0.7541500000000001, 'cached': 346560, 'duration_s': 38.80159319296945, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 459534, 'interactivity_p90': 52.889645788429384, 'level': 4.0, 'ok': 128, 'ok_ratio': 1.0, 'output': 16384, 'output_tps': 211.12632331901543, 'sent': 128, 'total_tps': 6132.7407155136, 'total_tps_per_gpu': 1533.1851788784, 'ttft_p50': 0.4031324112438597, 'ttft_p90': 0.7486960489186458}`
Valid points: 3

## fp8-kv-fp8_e4m3-mtp-natural

Best level: `4`; metrics: `{'accept_length': 2.4632874146001615, 'cache_hit': 0.7577, 'cached': 348224, 'duration_s': 44.0234885935206, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 459568, 'interactivity_p90': 40.83301761180704, 'level': 4.0, 'ok': 128, 'ok_ratio': 1.0, 'output': 16384, 'output_tps': 186.14347861416385, 'sent': 128, 'total_tps': 5407.436222206321, 'total_tps_per_gpu': 1351.8590555515802, 'ttft_p50': 0.4284760589944199, 'ttft_p90': 0.7705210272106342}`
Valid points: 3

## nvfp4-kv-fp8_e4m3-mtp-natural

Best level: `4`; metrics: `{'accept_length': 2.4676826129260925, 'cache_hit': 0.7555000000000001, 'cached': 347200, 'duration_s': 40.8421007724246, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 459545, 'interactivity_p90': 49.18520669638811, 'level': 4.0, 'ok': 128, 'ok_ratio': 1.0, 'output': 16384, 'output_tps': 200.58684412917918, 'sent': 128, 'total_tps': 5826.728997406168, 'total_tps_per_gpu': 1456.682249351542, 'ttft_p50': 0.4271584897651337, 'ttft_p90': 0.7900445226579904}`
Valid points: 3
