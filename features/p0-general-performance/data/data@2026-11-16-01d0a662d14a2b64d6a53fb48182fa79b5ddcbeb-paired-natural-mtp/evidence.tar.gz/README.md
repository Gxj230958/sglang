# Matched natural-MTP KV sweep

Prepared only; launch after the MTP-off sweep is terminal, its output is reviewed and GPU idleness is verified under the same exclusive lock.

Four candidates cross FP8/NVFP4 target weights with BF16 KV plus FlashMLA sparse / FP8 KV plus TRTLLM DSA. Runtime 01d0a662d14a2b64d6a53fb48182fa79b5ddcbeb, environment, workload, seeds, concurrency grid, SLO and throughput aggregation match the MTP-off round. Natural EAGLE uses steps/top-k/draft-tokens 3/1/4 and the original FP8 draft with explicit FP8 draft quantization. Every candidate checks these resolved settings and all four Rust ranks. All simulated-acceptance variables are removed before server launch.

Use the unchanged workspace serve_sweep.py through execute.py. The server adapter differs from the preceding round only in task paths; candidate arguments add the pinned draft configuration. The load adapter invokes the same benchmark CLI through capture_client.py, which preserves calculate_metrics output and records streamed text chunks, raw timing and per-chunk token counts after the measured load. This allows independent reconstruction of the existing retokenized MTP interactivity metric. Compare matched weight formats within each deployment. Compare MTP off versus natural MTP within a fixed weight format and KV deployment. Keep the full-GSM8K result visible: NVFP4 94.24% accuracy / 99.55% stop versus FP8 95.22% / 99.77% at the same runtime; performance-only scope and runtime publication held.

The bounded start.sh owns only processes carrying its unique GLM5LP_SWEEP_OWNER value. No automatic launch is scheduled for this prepared round. Archive raw measurements, resolved settings, per-rank Rust evidence and process ownership samples before releasing the lock.

The external load adapter recomputes the client P90 from captured per-chunk token counts and intervals before accepting each load summary. Startup requires a successful, complete four-arm MTP-off report and a fresh source/idle check. Estimated duration is 60–120 minutes from historical startup/load timings; the driver enforces a six-hour bound.
