import inspect
import json
import sys
from pathlib import Path

from sglang.benchmark import serving

output_path = Path(sys.argv.pop(1))
original = serving.calculate_metrics
signature = inspect.signature(original)


def capture_metrics(*args, **kwargs):
    bound = signature.bind(*args, **kwargs)
    bound.apply_defaults()
    result = original(*args, **kwargs)
    values = bound.arguments
    tokenizer = values['tokenizer']
    rows = []
    for index, output in enumerate(values['outputs']):
        counts = [len(tokenizer.encode(chunk, add_special_tokens=False)) for chunk in output.text_chunks]
        rows.append({'index': index, 'success': output.success, 'ttft': output.ttft, 'itls': output.itl, 'text_chunks': output.text_chunks, 'chunk_token_counts': counts})
    output_path.write_text(json.dumps({'backend': values['backend'], 'accept_length': values['accept_length'], 'tokenizer': tokenizer.name_or_path, 'client_p90_itl_ms': result[0].p90_itl_ms, 'requests': rows}) + '\n')
    return result


serving.calculate_metrics = capture_metrics
serving.cli_main()
