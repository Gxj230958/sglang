import runpy
import signal
from pathlib import Path

def interrupted(signum, frame):
    raise KeyboardInterrupt

signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGINT, interrupted)
runpy.run_path(str(Path(__file__).with_name('serve_sweep.py')), run_name='__main__')
