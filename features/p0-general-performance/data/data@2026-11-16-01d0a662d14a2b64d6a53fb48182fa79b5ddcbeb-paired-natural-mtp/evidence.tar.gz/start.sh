#!/usr/bin/env bash
set -euo pipefail
R=/scratch/glm5lp-paired-mtp-natural-01d0a662d1
S=/scratch/codex-glm5lp-current-head-01d0a662d1
export GLM5LP_SWEEP_OWNER="$(cat "$R/process-owner.txt")"
export PATH=/root/.cargo/bin:$PATH
export HF_HOME=/scratch/cc-pr43/hf-home HF_HUB_CACHE=/scratch/cc-pr43/hf-home
finish() {
  rc=$?
  trap - EXIT
  python3 "$R/cleanup.py" "$R/cleanup.json" || rc=125
  nvidia-smi --query-compute-apps=pid,process_name --format=csv,noheader > "$R/gpu-final-processes.csv" || rc=125
  nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits > "$R/gpu-final-memory.csv" || rc=125
  printf '%s\n' "$rc" > "$R/driver.exit"
  exit "$rc"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
[[ "$(cat "$S/nvfp4-full-driver.exit")" = 0 ]]
P=/scratch/codex-glm5lp-paired-sweep-01d0a662d1
[[ "$(cat "$P/driver.exit")" = 0 ]]
python3 -c 'import json,sys; r=json.load(open(sys.argv[1])); assert not r["failures"] and len(r["candidates"])==4; assert all(len(x["points"])==6 for x in r["candidates"])' "$P/run1/report.json"
python3 "$S/probe.py" > "$R/prelaunch-probe.json"
python3 -c 'import json,sys;sys.exit(not json.load(open(sys.argv[1]))["idle"])' "$R/prelaunch-probe.json"
python3 "$S/verify_source.py" "$S/source-manifest.json" "$S/src" > "$R/source-verification.json"
cd "$R"
timeout --signal=TERM --kill-after=90s 6h python3 -u execute.py run --config kv-mtp-natural.json --run-dir "$R/run1"
