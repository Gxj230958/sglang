# Serve sweep report

Recommended: `nvfp4-kv-bf16-mtp-natural`

## fp8-kv-bf16-mtp-natural

Best level: `1`; metrics: `{'accept_length': 2.422941176470588, 'cache_hit': 0.7791, 'cached': 179008, 'duration_s': 74.5516176421661, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 229771, 'interactivity_p90': 130.67050363214284, 'level': 1, 'ok': 64, 'ok_ratio': 1.0, 'output': 8192, 'output_tps': 109.88359822479075, 'sent': 64, 'total_tps': 3191.922690962632, 'total_tps_per_gpu': 797.980672740658, 'ttft_p50': 0.37950600939802825, 'ttft_p90': 0.3863618903560564}`
Valid points: 1

## nvfp4-kv-bf16-mtp-natural

Best level: `1`; metrics: `{'accept_length': 2.432440476190476, 'cache_hit': 0.7794, 'cached': 179072, 'duration_s': 70.31396367610432, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 229763, 'interactivity_p90': 144.79693603979015, 'level': 1, 'ok': 64, 'ok_ratio': 1.0, 'output': 8192, 'output_tps': 116.50601917047084, 'sent': 64, 'total_tps': 3384.1784413707746, 'total_tps_per_gpu': 846.0446103426937, 'ttft_p50': 0.3911400750512257, 'ttft_p90': 0.39915306146722285}`
Valid points: 1

## fp8-kv-fp8_e4m3-mtp-natural

Best level: `1`; metrics: `{'accept_length': 2.5367283950617283, 'cache_hit': 0.7746, 'cached': 177984, 'duration_s': 75.62206871202216, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 229789, 'interactivity_p90': 126.30239815086, 'level': 1, 'ok': 64, 'ok_ratio': 1.0, 'output': 8192, 'output_tps': 108.32816583206831, 'sent': 64, 'total_tps': 3146.9781778419733, 'total_tps_per_gpu': 786.7445444604933, 'ttft_p50': 0.3953313820529729, 'ttft_p90': 0.4050126306246966}`
Valid points: 1

## nvfp4-kv-fp8_e4m3-mtp-natural

Best level: `1`; metrics: `{'accept_length': 2.4698795180722892, 'cache_hit': 0.7776000000000001, 'cached': 178688, 'duration_s': 72.9573802461382, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 229787, 'interactivity_p90': 138.3494415507233, 'level': 1, 'ok': 64, 'ok_ratio': 1.0, 'output': 8192, 'output_tps': 112.28473353021226, 'sent': 64, 'total_tps': 3261.8906983381817, 'total_tps_per_gpu': 815.4726745845454, 'ttft_p50': 0.4053009750787169, 'ttft_p90': 0.41229948550462725}`
Valid points: 1
