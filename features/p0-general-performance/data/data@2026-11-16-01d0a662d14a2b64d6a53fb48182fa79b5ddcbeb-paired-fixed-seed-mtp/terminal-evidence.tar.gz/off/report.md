# Serve sweep report

Recommended: `nvfp4-kv-fp8_e4m3-mtp-off`

## fp8-kv-bf16-mtp-off

Best level: `32`; metrics: `{'cache_hit': 0.77555, 'cached': 1425600, 'duration_s': 46.518273554043844, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838115, 'interactivity_p90': 32.13884544249119, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 704.4617451594056, 'sent': 512, 'total_tps': 20462.790204457066, 'total_tps_per_gpu': 5115.697551114266, 'ttft_p50': 1.8664822214632295, 'ttft_p90': 2.350613975955639}`
Valid points: 6

## nvfp4-kv-bf16-mtp-off

Best level: `32`; metrics: `{'cache_hit': 0.7704000000000001, 'cached': 1416192, 'duration_s': 38.553660865989514, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838177, 'interactivity_p90': 41.54876675742073, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 849.946101031007, 'sent': 512, 'total_tps': 24689.53548032926, 'total_tps_per_gpu': 6172.383870082315, 'ttft_p50': 1.6271932134986855, 'ttft_p90': 2.04184634500416}`
Valid points: 6

## fp8-kv-fp8_e4m3-mtp-off

Best level: `32`; metrics: `{'cache_hit': 0.7718499999999999, 'cached': 1418688, 'duration_s': 45.23162958107423, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838116, 'interactivity_p90': 32.499927196209505, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 724.4556979156482, 'sent': 512, 'total_tps': 21043.572737749844, 'total_tps_per_gpu': 5260.893184437461, 'ttft_p50': 1.7209943255293183, 'ttft_p90': 2.140693007502705}`
Valid points: 6

## nvfp4-kv-fp8_e4m3-mtp-off

Best level: `32`; metrics: `{'cache_hit': 0.7687999999999999, 'cached': 1413312, 'duration_s': 37.98839851934463, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838240, 'interactivity_p90': 42.51905290255111, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 862.5950508507915, 'sent': 512, 'total_tps': 25057.795431935978, 'total_tps_per_gpu': 6264.4488579839945, 'ttft_p50': 1.6138331968104467, 'ttft_p90': 2.0289898347691633}`
Valid points: 6
