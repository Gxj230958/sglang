#!/usr/bin/env bash
set -euo pipefail
R=/scratch/glm5lp-paired-controlled-01d0a662d1
S=/scratch/codex-glm5lp-current-head-01d0a662d1
P=/scratch/glm5lp-paired-mtp-natural-01d0a662d1
test ! -d "$R/gate"
test ! -d "$R/off"
test ! -d "$R/controlled"
export GLM5LP_SWEEP_OWNER="$(cat "$R/process-owner.txt")"
export PATH=/root/.cargo/bin:$PATH
export HF_HOME=/scratch/cc-pr43/hf-home HF_HUB_CACHE=/scratch/cc-pr43/hf-home
finish() {
  rc=$?
  trap - EXIT
  python3 "$R/cleanup.py" "$R/cleanup.json" || rc=125
  nvidia-smi --query-compute-apps=pid,process_name --format=csv,noheader > "$R/gpu-final-processes.csv" || rc=125
  nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits > "$R/gpu-final-memory.csv" || rc=125
  printf '%s\n' "$rc" > "$R/driver.exit"
  exit "$rc"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
[[ "$(cat "$P/driver.exit")" = 0 ]]
python3 -c 'import json,sys; r=json.load(open(sys.argv[1])); assert not r["failures"] and len(r["candidates"])==4; assert all(len(x["points"])==6 for x in r["candidates"])' "$P/run1/report.json"
python3 "$S/probe.py" > "$R/prelaunch-probe.json"
python3 -c 'import json,sys; assert json.load(open(sys.argv[1]))["idle"]' "$R/prelaunch-probe.json"
python3 "$S/verify_source.py" "$S/source-manifest.json" "$S/src" > "$R/source-verification.json"
cd "$R"
python3 -u execute.py run --config natural-gate.json --run-dir "$R/gate"
python3 -c 'import json,sys; r=json.load(open(sys.argv[1])); assert not r["failures"] and len(r["candidates"])==4; assert all(len(x["points"])==1 and x["points"][0]["pass"] for x in r["candidates"])' "$R/gate/report.json"
python3 -u execute.py run --config mtp-off.json --run-dir "$R/off"
python3 -c 'import json,sys; r=json.load(open(sys.argv[1])); assert not r["failures"] and len(r["candidates"])==4; assert all(len(x["points"])==6 for x in r["candidates"])' "$R/off/report.json"
python3 -u execute.py run --config controlled35.json --run-dir "$R/controlled"
python3 -c 'import json,sys; r=json.load(open(sys.argv[1])); assert not r["failures"] and len(r["candidates"])==4; assert all(len(x["points"])==6 for x in r["candidates"])' "$R/controlled/report.json"
python3 "$S/verify_source.py" "$S/source-manifest.json" "$S/src" > "$R/postrun-source-verification.json"
