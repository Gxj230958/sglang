# Serve sweep report

Recommended: `nvfp4-kv-fp8_e4m3-mtp-controlled35`

## fp8-kv-bf16-mtp-controlled35

Best level: `32`; metrics: `{'accept_length': 3.5, 'cache_hit': 0.7699, 'cached': 1414912, 'duration_s': 30.95300044142641, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1837807, 'interactivity_p90': 64.77699522735641, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 1059.0637451667917, 'sent': 512, 'total_tps': 30757.980979298678, 'total_tps_per_gpu': 7689.4952448246695, 'ttft_p50': 2.1212118075345643, 'ttft_p90': 2.6027239382383414}`
Valid points: 6

## nvfp4-kv-bf16-mtp-controlled35

Best level: `32`; metrics: `{'accept_length': 3.5, 'cache_hit': 0.7694000000000001, 'cached': 1413760, 'duration_s': 26.127731359447353, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1837555, 'interactivity_p90': 85.42681201410619, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 1254.4173654283356, 'sent': 512, 'total_tps': 36426.86697842385, 'total_tps_per_gpu': 9106.716744605963, 'ttft_p50': 1.9186595677747391, 'ttft_p90': 2.144481904048007}`
Valid points: 6

## fp8-kv-fp8_e4m3-mtp-controlled35

Best level: `32`; metrics: `{'accept_length': 3.5, 'cache_hit': 0.7658, 'cached': 1407168, 'duration_s': 30.147728648618795, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1837580, 'interactivity_p90': 66.30517384488817, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 1086.9273777201433, 'sent': 512, 'total_tps': 31563.549471472732, 'total_tps_per_gpu': 7890.887367868183, 'ttft_p50': 2.199356741271913, 'ttft_p90': 2.292521573952399}`
Valid points: 6

## nvfp4-kv-fp8_e4m3-mtp-controlled35

Best level: `32`; metrics: `{'accept_length': 3.5, 'cache_hit': 0.77045, 'cached': 1415744, 'duration_s': 25.57493760646321, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1837574, 'interactivity_p90': 87.9725921449855, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 1281.4593499036332, 'sent': 512, 'total_tps': 37212.428204285294, 'total_tps_per_gpu': 9303.107051071323, 'ttft_p50': 1.864145433763042, 'ttft_p90': 2.2291840614634566}`
Valid points: 6
