import concurrent.futures
import json
from pathlib import Path
import random
import re
import sys
import urllib.request

endpoint, output, phase = sys.argv[1:4]
output = Path(output)
output.mkdir(parents=True, exist_ok=True)
with urllib.request.urlopen(endpoint + '/v1/models', timeout=10) as response:
    model = json.load(response)['data'][0]['id']

def document(tag):
    rng = random.Random(tag)
    codes = [rng.randrange(100000, 999999) for _ in range(6600 // 13)]
    text = f'Session {tag}.\n' + '\n'.join(f'Record {i}: the code is {value}.' for i, value in enumerate(codes))
    return text, codes

def chat(name, prompt, max_tokens):
    body = {'model': model, 'messages': [{'role': 'user', 'content': prompt}], 'temperature': 0, 'seed': 1, 'max_tokens': max_tokens, 'chat_template_kwargs': {'enable_thinking': False}, 'return_cached_tokens_details': True, 'return_output_ids_in_sglext': True, 'logprobs': True, 'top_logprobs': 1}
    (output / (name + '-request.json')).write_text(json.dumps(body, indent=2))
    request = urllib.request.Request(endpoint + '/v1/chat/completions', data=json.dumps(body).encode(), headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(request, timeout=1800) as response:
        result = json.load(response)
    (output / (name + '-response.json')).write_text(json.dumps(result, indent=2))
    return result

def metrics(name):
    with urllib.request.urlopen(endpoint + '/metrics', timeout=10) as response:
        (output / (name + '.metrics')).write_bytes(response.read())

metrics('before')
if phase == 'fill':
    count = int(sys.argv[4])
    tag = sys.argv[5]
    assert 1 <= count <= 256
    def fill(index):
        text, _ = document(f'{tag}-{index}')
        response = chat(f'fill-{index}', text + '\n\nReply with OK.', 2)
        choice = response['choices'][0]
        assert choice['finish_reason'] in ('stop', 'length')
        return {'index': index, 'finish': choice['finish_reason'], 'usage': response['usage']}
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        result = list(pool.map(fill, range(count)))
else:
    text, codes = document('rust-hicache-anchor-v1')
    indices = [len(codes) // 2, len(codes) // 2 + 1, len(codes) // 2 + 2, 3, len(codes) - 2]
    expected = [codes[i] for i in indices]
    prompt = text + '\n\nList the codes of Records ' + ', '.join(map(str, indices)) + ', in that order, separated by commas.'
    response = chat(phase, prompt, 128)
    choice = response['choices'][0]
    values = [int(x) for x in re.findall(r'(?<!\d)\d{6}(?!\d)', choice['message'].get('content') or '')]
    details = response['sglext']['cached_tokens_details']
    assert values == expected and choice['finish_reason'] == 'stop', (values, expected, choice['finish_reason'])
    assert response['sglext']['output_ids'], 'Missing generated-token evidence'
    assert details.get('storage_backend') == 'file', details
    if phase in ('cold', 'negative'):
        assert details['device'] == details['host'] == details['storage'] == 0, details
    elif phase == 'device':
        assert details['device'] > 0 and details['host'] == details['storage'] == 0, details
    elif phase == 'host':
        assert details['host'] > 0 and details['storage'] == 0, details
    elif phase == 'storage':
        assert details['storage'] > 0, details
    else:
        raise ValueError(phase)
    result = {'phase': phase, 'correct': True, 'finish_reason': choice['finish_reason'], 'expected_codes': expected, 'cached_tokens_details': details, 'usage': response['usage'], 'output_ids': response['sglext']['output_ids']}
metrics('after')
(output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
