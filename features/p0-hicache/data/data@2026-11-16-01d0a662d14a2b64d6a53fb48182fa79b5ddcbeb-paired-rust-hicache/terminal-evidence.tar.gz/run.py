import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import traceback
import urllib.request

root = Path(__file__).resolve().parent
plan = json.loads((root / 'plan.json').read_text())
env = dict(os.environ, **plan['environment'], CUDA_VISIBLE_DEVICES='0,1,2,3', OMP_NUM_THREADS='4')
for key in list(env):
    if key.startswith('SGLANG_SIMULATE_ACC_') or key == 'SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND' or key == 'SGLANG_HICACHE_FILE_BACKEND_STORAGE_DIR':
        env.pop(key)
endpoint = 'http://127.0.0.1:31994'
server = None

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def request(resource, body=None):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(endpoint + '/' + resource, data=data, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=10) as response:
        return response.read()

def stop():
    global server
    if server is None:
        return
    try:
        os.killpg(server.pid, signal.SIGTERM)
        try:
            server.wait(timeout=30)
        except subprocess.TimeoutExpired:
            pass
        os.killpg(server.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    server.wait(timeout=10)
    server = None

def interrupted(signum, frame):
    raise SystemExit(128 + signum)

def command(folder, name, args, timeout, command_env=env):
    write(folder / (name + '-command.json'), args)
    with (folder / (name + '.log')).open('wb') as log:
        subprocess.run(args, env=command_env, stdout=log, stderr=subprocess.STDOUT, timeout=timeout, check=True)

def probe(folder, phase, *args):
    destination = folder / phase
    command(folder, phase, [sys.executable, str(root / 'cache-probe.py'), endpoint, str(destination), phase, *map(str, args)], 3600)
    return json.loads((destination / 'result.json').read_text())

def start(candidate, phase, storage):
    global server
    folder = root / 'results' / candidate['name'] / phase
    folder.mkdir(parents=True, exist_ok=False)
    for port in [31994, 31995]:
        with socket.socket() as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(('127.0.0.1', port))
    args = [sys.executable, str(root / 'server.py'), str(folder), *[str(storage) if x == '{storage_dir}' else x for x in candidate['args']]]
    write(folder / 'launch.json', {'command': args, 'environment': {k: env[k] for k in plan['environment']}, 'storage_dir': str(storage)})
    with (folder / 'replica-0.log').open('wb') as log:
        server = subprocess.Popen(args, cwd=plan['source'], env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    write(folder / 'server-process.json', {'pid': server.pid, 'pgid': server.pid})
    deadline = time.monotonic() + 1800
    while True:
        assert server.poll() is None, ('server exited', server.returncode)
        try:
            request('health')
            break
        except (OSError, TimeoutError):
            assert time.monotonic() < deadline, 'startup deadline exceeded'
            time.sleep(5)
    expected = dict(candidate['expected'], file_storage_path=str(storage))
    command(folder, 'runtime-evidence', [sys.executable, str(root / 'runtime-evidence.py'), endpoint, candidate['model'], str(folder / 'runtime-evidence.json'), json.dumps(expected)], 60)
    (folder / 'flush-response.txt').write_bytes(request('flush_cache', {}))
    return folder

def evaluate(folder, candidate):
    (folder / 'metrics-before-eval.txt').write_bytes(request('metrics'))
    args = [plan['eval_executable'], 'run', 'gsm8k', '--base-url', endpoint + '/v1', '--model', candidate['model'], '--temperature', '1.0', '--top-p', '0.95', '--seed', '1', '--num-threads', '64', '--max-tokens', '32768', '--out-dir', str(folder / 'gsm8k')]
    eval_env = dict(os.environ, PYTHONPATH='', PYTHONNOUSERSITE='1', CUDA_VISIBLE_DEVICES='', OPENAI_API_KEY='dummy')
    command(folder, 'gsm8k', args, 10800, eval_env)
    metrics_files = list((folder / 'gsm8k').rglob('metrics.json'))
    predictions = list((folder / 'gsm8k').rglob('output-rs0.jsonl'))
    assert len(metrics_files) == len(predictions) == 1
    metrics = json.loads(metrics_files[0].read_text())
    rows = [json.loads(line) for line in predictions[0].read_text().splitlines()]
    assert len(rows) == 1319 and {row['id'] for row in rows} == {f'gsm8k-{i}' for i in range(1319)}
    assert metrics['aggregate']['error_rate'] == 0, metrics['aggregate']
    assert all(row['finish_reason'] in ('stop', 'length') for row in rows)
    (folder / 'metrics-after-eval.txt').write_bytes(request('metrics'))
    (folder / 'server-info-final.json').write_bytes(request('get_server_info'))

for sig in [signal.SIGTERM, signal.SIGINT]:
    signal.signal(sig, interrupted)
result = {'runtime': plan['runtime'], 'started': time.time(), 'candidates': []}
try:
    for candidate in plan['candidates']:
        storage = root / 'stores' / candidate['name'] / 'positive'
        storage.mkdir(parents=True, exist_ok=False)
        assert not list(storage.iterdir())
        first = start(candidate, 'host', storage)
        cold = probe(first, 'cold')
        device = probe(first, 'device')
        info = json.loads(request('get_server_info'))
        write(first / 'server-info-before-fill.json', info)
        fill = probe(first, 'fill', 70, candidate['name'] + '-fill-v1')
        assert sum(x['usage']['prompt_tokens'] for x in fill) > info['max_total_num_tokens'], 'Fill did not exceed resolved device capacity'
        host = probe(first, 'host')
        command(first, 'prefix', [sys.executable, str(root / 'midfork.py'), endpoint + '/v1', str(first / 'prefix.json'), 'hicache-rust-v1'], 1800)
        prefix = json.loads((first / 'prefix.json').read_text())
        assert len(prefix) == 6 and all(x['text'].strip() == x['expected'] and x['finish'] == 'stop' for x in prefix)
        evaluate(first, candidate)
        write(first / 'storage-inventory.json', [{'path': str(p.relative_to(storage)), 'bytes': p.stat().st_size} for p in storage.rglob('*') if p.is_file()])
        assert any(p.is_file() for p in storage.rglob('*')), 'No storage files'
        stop()
        time.sleep(5)
        restored = start(candidate, 'storage', storage)
        storage_result = probe(restored, 'storage')
        evaluate(restored, candidate)
        stop()
        time.sleep(5)
        negative_storage = storage.parent / 'negative'
        negative_storage.mkdir(exist_ok=False)
        assert not list(negative_storage.iterdir())
        negative_folder = start(candidate, 'negative', negative_storage)
        negative = probe(negative_folder, 'negative')
        record = {'name': candidate['name'], 'status': 'measurements_complete_review_required', 'cache_details': {k: v['cached_tokens_details'] for k, v in [('cold', cold), ('device', device), ('host', host), ('storage', storage_result), ('negative', negative)]}, 'output_ids_equal_to_device': {k: v['output_ids'] == device['output_ids'] for k, v in [('cold', cold), ('host', host), ('storage', storage_result), ('negative', negative)]}}
        result['candidates'].append(record)
        write(root / 'result.json', result)
        stop()
        time.sleep(5)
    result['status'] = 'measurements_complete_review_required'
except BaseException as error:
    result.update(status='failed', error=repr(error), traceback=traceback.format_exc())
    print(result['traceback'], flush=True)
finally:
    stop()
    result['finished'] = time.time()
    write(root / 'result.json', result)
raise SystemExit(0 if result.get('status') == 'measurements_complete_review_required' else 1)
