import json,pathlib,sys
r=pathlib.Path(sys.argv[1]);retrieval=json.loads((r/'retrieval.json').read_text());prefix=json.loads((r/'prefix.json').read_text())
assert len(retrieval)==18 and len(prefix)==6
assert {x['target'] for x in retrieval}=={300,3000,9000,24000,60000,110000}
assert {x['case'] for x in prefix}=={'first','identical','fork_at_end','mid_fork_late_record','mid_fork_early_record','follow_up_turn'}
retrieval_failures=[{'target':x['target'],'record':x['record'],'correct':x['correct'],'finish_reason':x['finish_reason']} for x in retrieval if not x['correct'] or x['finish_reason']!='stop']
prefix_failures=[{'case':x['case'],'correct':x['correct'],'finish_reason':x['finish']} for x in prefix if not x['correct'] or x['finish']!='stop']
result={'retrieval_count':18,'retrieval_passed':18-len(retrieval_failures),'retrieval_failures':retrieval_failures,'prefix_count':6,'prefix_passed':6-len(prefix_failures),'prefix_failures':prefix_failures,'all_functional_passed':not retrieval_failures and not prefix_failures}
(r/'functional-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
