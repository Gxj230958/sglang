import json,pathlib,sys
root=pathlib.Path(sys.argv[1]);retrieval=json.loads((root/'retrieval.json').read_text());routing=json.loads((root/'dp-probes/result.json').read_text())
assert len(retrieval)==18 and routing['requests']==16
assert {x['target'] for x in retrieval}=={300,3000,9000,24000,60000,110000}
assert {(x['rank'],x['phase']) for x in routing['rows']}=={(i,phase) for i in range(4) for phase in ['cold','warm','fork','warm-fork']}
failures=[{'target':x['target'],'record':x['record'],'text':x['text'],'expected':x['expected'],'finish_reason':x['finish_reason']} for x in retrieval if x['text'].strip()!=x['expected'] or x['finish_reason']!='stop']
result={'retrieval_count':18,'retrieval_passed':18-len(failures),'retrieval_failures':failures,'directed_count':16,'routing_gates':routing['gates'],'all_functional_passed':not failures and all(routing['gates'].values())}
(root/'functional-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
