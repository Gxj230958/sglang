import hashlib,json,os,socket,subprocess
from pathlib import Path

root=Path(__file__).resolve().parent
plan=json.loads((root/'plan.json').read_text())
files=json.loads((root/'files.json').read_text())
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in files.items())
prior=Path('/scratch/glm5lp-current-h200-01d0a662d1')
assert (prior/'driver.exit').read_text().strip()=='0'
assert not Path('/proc/'+(prior/'driver.pid').read_text().strip()).exists()
probe=json.loads(subprocess.check_output(['python3',str(root/'probe.py')],text=True));assert probe['idle'],probe
for port in [31880,31881]:
    with socket.socket() as s:s.bind(('127.0.0.1',port))
source=json.loads(subprocess.check_output(['python3',str(root/'verify_source.py'),str(root/'source-manifest.json'),plan['source']],text=True));assert not source['mismatches']
assert {n:hashlib.sha256((Path(plan['model'])/n).read_bytes()).hexdigest() for n in plan['model_metadata']}==plan['model_metadata']
env=dict(os.environ,**plan['environment'])
code='import importlib.metadata as m,json,sys;print(json.dumps({n:m.version(n) for n in json.loads(sys.argv[1])}))'
versions=json.loads(subprocess.check_output(['/opt/sglang/bin/python','-c',code,json.dumps(list(plan['package_versions']))],env=env,text=True));assert versions==plan['package_versions'],versions
help_text=subprocess.check_output(['/opt/sglang/bin/sgl-eval','run','--help'],env=env,text=True)
for option in ['--seed','--num-threads','--max-tokens']:assert option in help_text,option
result={'files_verified':len(files),'source':source,'probe':probe,'versions':versions,'evaluation_flags_verified':True}
(root/'preflight.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
