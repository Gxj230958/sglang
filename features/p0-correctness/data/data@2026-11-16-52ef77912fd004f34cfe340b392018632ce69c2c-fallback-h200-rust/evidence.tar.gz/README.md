# November 18 fallback candidate H200 gate

Full 1319 GSM8K examples: T1, top_p 0.95, seed 1, 64 threads, max_tokens 32768. TP8, BF16 KV, FlashMLA sparse, natural EAGLE 3/1/4, original FP8 draft, eager prefill. Inspect accuracy and every finish reason. Capture actual Rust mappings for all eight workers and verify every tracked source file before and after. Candidate 52ef77912fd004f34cfe340b392018632ce69c2c. Optional fused H64 decode is disabled. Six-hour watchdog and owner-specific cleanup.
