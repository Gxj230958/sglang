import hashlib
import json
import os
import subprocess
from pathlib import Path


def completed_eval_wrapper(directory, argv):
    try:
        fields=(directory/'stat').read_text().rsplit(')',1)[1].split()
        if directory.name!='2332869' or fields[19]!='286496190' or fields[1]!='1':
            return False
        if [x for x in argv if x]!=['bash','/scratch/ling32/run_gsm8k.sh','/scratch/ling32/eval-per-call-h200-standard']:
            return False
        if (directory/'task/2332869/children').read_text().split()!=['2332872']:
            return False
        child=Path('/proc/2332872')
        if (child/'stat').read_text().rsplit(')',1)[1].split()[1]!='2332869':
            return False
        if [x for x in (child/'cmdline').read_bytes().decode().split('\0') if x]!=['tee','/scratch/ling32/eval-per-call-h200-standard/eval.log']:
            return False
        if (child/'task/2332872/children').read_text().strip():
            return False
        script=Path('/scratch/ling32/run_gsm8k.sh')
        metrics=Path('/scratch/ling32/eval-per-call-h200-standard/sgl_eval_gsm8k_20261106-214057/metrics.json')
        return hashlib.sha256(script.read_bytes()).hexdigest()=='f4efed3a2fae4a0f8c9c0370d67db1dac3bbfb53d6dbb97332666091accbbf7e' and hashlib.sha256(metrics.read_bytes()).hexdigest()=='f7509e96458aab188041263b946899c8e504a27b6150fb47a20b8fb699d6d965'
    except (OSError,ValueError,IndexError):
        return False

excluded = {os.getpid()}
pid = os.getpid()
while pid > 1:
    try:
        stat = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        pid = int(stat[1])
        excluded.add(pid)
    except (OSError, ValueError):
        break
blocked = []
ignored_terminal_wrappers = []
for d in Path('/proc').iterdir():
    if not d.name.isdigit() or int(d.name) in excluded:
        continue
    try:
        argv = (d / 'cmdline').read_bytes().decode(errors='replace').split('\0')
        comm = (d / 'comm').read_text().strip()
    except (OSError, ProcessLookupError):
        continue
    if not argv or not argv[0]:
        continue
    python_job = comm.startswith(('python', 'sglang')) and not any('mutagen' in a for a in argv)
    scratch_driver = Path(argv[0]).name in ('bash', 'sh', 'zsh') and any('/scratch/' in a for a in argv[1:])
    if scratch_driver and completed_eval_wrapper(d, argv):
        ignored_terminal_wrappers.append({'pid':int(d.name),'reason':'completed November 6 evaluation; only orphan tee remains'})
        continue
    if python_job or scratch_driver:
        blocked.append({'pid': int(d.name), 'comm': comm, 'entry': next((Path(a).name for a in argv[1:] if a.endswith(('.py', '.sh'))), '')})
p = subprocess.run(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader,nounits'], capture_output=True, text=True)
m = subprocess.run(['nvidia-smi', '--query-gpu=memory.used', '--format=csv,noheader,nounits'], capture_output=True, text=True)
try:
    memory = [int(x.strip()) for x in m.stdout.splitlines()]
except ValueError:
    memory = []
idle = p.returncode == 0 and m.returncode == 0 and not p.stdout.strip() and len(memory) == 8 and max(memory) < 2000 and not blocked
print(json.dumps({'idle': idle, 'blocked': blocked, 'memory_mib': memory, 'gpu_pids': p.stdout.splitlines(), 'ignored_terminal_wrappers': ignored_terminal_wrappers}))
