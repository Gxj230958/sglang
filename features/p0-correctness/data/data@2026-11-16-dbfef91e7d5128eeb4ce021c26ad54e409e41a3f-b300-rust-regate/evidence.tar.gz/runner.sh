#!/usr/bin/env bash
set -euo pipefail
R=${R:?set a fresh output directory}
S=${S:?set the verified source archive path}
M=${M:?set the checkpoint path}
OVERLAY=${OVERLAY:?set the dependency overlay}
P=${P:-31749}
PY=${PY:-/opt/sglang/bin/python}
EVAL=${EVAL:-/opt/sglang/bin/sgl-eval}
SERVER_PID=
MONITOR_PID=
mkdir "$R"
R=$(realpath "$R")
export PATH=/root/.cargo/bin:$PATH
export PYTHONPATH="$OVERLAY:$S/python"
export SGLANG_RUST_BUILD_MODE=auto
unset SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND
ST=$R/status
stop_server() {
  if [[ -n "$MONITOR_PID" ]]; then
    kill "$MONITOR_PID" 2>/dev/null || true
    wait "$MONITOR_PID" 2>/dev/null || true
    MONITOR_PID=
  fi
  if [[ -n "$SERVER_PID" ]]; then
    kill -TERM -- "-$SERVER_PID" 2>/dev/null || true
    for _ in $(seq 1 30); do
      kill -0 -- "-$SERVER_PID" 2>/dev/null || break
      sleep 1
    done
    kill -KILL -- "-$SERVER_PID" 2>/dev/null || true
    wait "$SERVER_PID" 2>/dev/null || true
    SERVER_PID=
  fi
}
trap stop_server EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
idle() {
  nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits > "$R/gpu-processes-before.txt"
  [[ ! -s "$R/gpu-processes-before.txt" ]] || { echo GPU_PROCESS_BUSY >> "$ST"; return 1; }
  nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits > "$R/gpu-memory-before.txt"
  awk '$1>2000 {bad=1} END {exit bad}' "$R/gpu-memory-before.txt"
  if curl -sf -m 3 "localhost:$P/health" >/dev/null; then
    echo PORT_BUSY >> "$ST"
    return 1
  fi
}
idle
cd "$S/rust"
cargo --version > "$R/toolchain.txt"
rustc --version >> "$R/toolchain.txt"
cd "$S"
"$PY" -c 'from sglang.srt.mem_cache.rust_tree_core.extension import bindings; print(bindings.__file__)' > "$R/rust-extension.txt" 2> "$R/rust-build.log"
common=(--model-path "$M" --host 127.0.0.1 --port "$P" --max-running-requests 32 --cuda-graph-max-bs-decode 32 --disable-prefill-cuda-graph --enable-cache-report --reasoning-parser glm45 --tool-call-parser glm47 --enable-metrics --speculative-algorithm EAGLE --speculative-num-steps 3 --speculative-eagle-topk 1 --speculative-num-draft-tokens 4 --speculative-draft-model-path "$M")
snap() {
  curl -fsS -m 20 "localhost:$P/metrics" > "$L/$1.metrics"
}
bench() {
  local name=$1 input=$2 output=$3 count=$4 concurrency=$5 seed=$6
  "$PY" -m sglang.bench_serving --backend sglang --host 127.0.0.1 --port "$P" --model "$M" --dataset-name random-ids --random-input-len "$input" --random-output-len "$output" --random-range-ratio 1 --num-prompts "$count" --max-concurrency "$concurrency" --seed "$seed" --flush-cache --warmup-requests 2 --output-file "$L/$name-s$seed.jsonl" > "$L/$name-s$seed.log" 2>&1
  echo "$ARM $name seed=$seed completed $(date -u +%FT%TZ)" >> "$ST"
}
for ARM in tp8-bf16 tp8-fp8 dep8; do
  idle
  L=$R/$ARM
  mkdir "$L"
  case "$ARM" in
    tp8-bf16) flags=(--tp-size 8 --mem-fraction-static 0.75 --context-length 65536 --chunked-prefill-size 32768);;
    tp8-fp8) flags=(--tp-size 8 --mem-fraction-static 0.75 --context-length 65536 --chunked-prefill-size 32768 --dsa-prefill-backend trtllm --dsa-decode-backend trtllm --kv-cache-dtype fp8_e4m3);;
    dep8) flags=(--tp-size 8 --ep-size 8 --attn-dp-size 8 --moe-runner-backend flashinfer_trtllm --moe-a2a-backend none --dsa-prefill-backend trtllm --dsa-decode-backend trtllm --kv-cache-dtype fp8_e4m3 --context-length 147456 --mem-fraction-static 0.88 --chunked-prefill-size 65536 --enable-fp32-lm-head);;
  esac
  printf '%q ' "$PY" -m sglang.launch_server "${common[@]}" "${flags[@]}" > "$L/argv.txt"
  printf '\n' >> "$L/argv.txt"
  setsid "$PY" -m sglang.launch_server "${common[@]}" "${flags[@]}" > >(tee "$L/serve.log") 2>&1 &
  SERVER_PID=$!
  echo "$SERVER_PID" > "$L/server-pgid.txt"
  (
    while kill -0 "$SERVER_PID" 2>/dev/null; do
      date -u +%FT%TZ
      nvidia-smi --query-compute-apps=pid,gpu_uuid,used_gpu_memory --format=csv,noheader
      ps -eo pid,ppid,pgid,comm
      sleep 2
    done
  ) > "$L/gpu-ownership.log" 2>&1 &
  MONITOR_PID=$!
  ready=0
  for _ in $(seq 1 420); do
    if curl -sf -m 3 "localhost:$P/health" >/dev/null; then ready=1; break; fi
    kill -0 "$SERVER_PID" 2>/dev/null || break
    sleep 10
  done
  [[ "$ready" = 1 ]] || { echo "NOT_READY $ARM" >> "$ST"; exit 1; }
  grep 'Tree Core:' "$L/serve.log" > "$L/treecore.txt"
  for rank in $(seq 0 7); do
    grep -E "TP${rank}([^0-9]|$).*Tree Core: RustUnifiedTreeCore" "$L/treecore.txt" >/dev/null || { echo "RUST_UNVERIFIED $ARM rank=$rank" >> "$ST"; exit 1; }
  done
  if grep -E 'Tree Core: (Python|UnifiedTreeCore)|Using the Python TreeCore' "$L/serve.log"; then
    echo "PYTHON_FALLBACK $ARM" >> "$ST"
    exit 1
  fi
  curl -fsS -m 20 "localhost:$P/get_server_info" > "$L/server_info.json"
  echo "RUST_READY $ARM $(date -u +%FT%TZ)" >> "$ST"
  echo "CORRECTNESS_ONLY_NVFP4_PERF_PAIR_PENDING $ARM" >> "$ST"
  snap before-t1
  "$EVAL" run gsm8k --base-url "http://127.0.0.1:$P/v1" --temperature 1.0 --top-p 0.95 --out-dir "$L/eval-t1" > "$L/gsm8k-t1.log" 2>&1
  snap after-t1
  curl -fsS -m 5 "localhost:$P/health" >/dev/null
  echo "EVAL_COMPLETED_REVIEW_REQUIRED $ARM $(date -u +%FT%TZ)" >> "$ST"
  stop_server
done
echo MEASUREMENTS_COMPLETED_REVIEW_REQUIRED >> "$ST"
