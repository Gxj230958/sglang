import hashlib,json,pathlib,re,subprocess,sys
out=pathlib.Path(sys.argv[3]).parent
log=(out/'serve.log').read_text(errors='replace')
lines=[line for line in log.splitlines() if 'Init Unified Radix Cache.' in line and 'Tree Core:' in line]
assert lines,'missing tree-core initialization evidence'
assert all('Tree Core: RustUnifiedTreeCore' in line for line in lines),lines
ranks={int(m[1]):int(m[2]) for line in lines if (m:=re.search(r'TP(\d+)(?: EP\d+)? PID(\d+)',line))}
assert set(ranks)==set(range(8)),ranks
expected=json.loads(sys.argv[4])
record={'selected':'rust','lines':lines,'ranks':{}}
process_environment={}
for rank,pid in ranks.items():
 env=dict(x.split('=',1) for x in pathlib.Path(f'/proc/{pid}/environ').read_bytes().decode().split('\0') if '=' in x)
 network=json.loads((pathlib.Path(__file__).parent/'plan.json').read_text())['network_environment']
 observation=json.loads((pathlib.Path(__file__).parent/'plan.json').read_text())['observation_environment']
 required={**network,**observation}
 process_environment[rank]={'pid':pid,'actual':{k:env.get(k) for k in required},'expected':required}
 (out/'process-environment.json').write_text(json.dumps(process_environment,indent=2))
 assert all(env.get(k)==v for k,v in required.items()),process_environment[rank]
 maps=pathlib.Path(f'/proc/{pid}/maps').read_text()
 paths=sorted({line.split()[-1] for line in maps.splitlines() if 'mem_cache' in line and '.so' in line})
 assert paths,('Rust shared object not mapped',rank,pid)
 fields=pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
 assert fields[0]!='Z'
 record['ranks'][rank]={'pid':pid,'start_ticks':fields[19],'network_environment':{k:env[k] for k in network},'extensions':[{'path':p,'sha256':hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()} for p in paths]}
(out/'tree-core.json').write_text(json.dumps(record,indent=2))
import urllib.request
with urllib.request.urlopen(sys.argv[1]+'/get_server_info',timeout=10) as response: info=json.load(response)
expected=json.loads(sys.argv[4])
assert all(info.get(k)==v for k,v in expected.items()),{k:info.get(k) for k in expected}
record['resolved']={k:info[k] for k in expected}
record['simulation']=json.loads((out/'server-imports.json').read_text())['simulation']
pathlib.Path(sys.argv[3]).write_text(json.dumps(record,indent=2))
