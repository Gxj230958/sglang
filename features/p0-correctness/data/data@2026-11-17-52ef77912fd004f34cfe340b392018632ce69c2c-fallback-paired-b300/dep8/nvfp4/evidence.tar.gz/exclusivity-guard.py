
import json,os,signal,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
plan=json.loads((root/'plan.json').read_text())
def identity(pid):
    p=Path('/proc')/str(pid);s=(p/'stat').read_text().rsplit(')',1)[1].split()
    return {'pid':pid,'start_ticks':s[19],'state':s[0],'ppid':int(s[1]),'argv':(p/'cmdline').read_bytes().decode(errors='replace').rstrip('\0').split('\0'),'owned':('GLM5LP_SWEEP_OWNER='+plan['owner']).encode() in (p/'environ').read_bytes().split(b'\0')}
def driver_live():
    try:
        d=identity(launch['pid'])
        return d['state']!='Z' and d['start_ticks']==launch['start_ticks'] and d['argv'][0]=='timeout' and d['argv'][-1]==str(root/'start.sh')
    except (FileNotFoundError,ProcessLookupError):return False
def stop(reason,record):
    result={'observed_at':time.time(),'reason':reason,'target':launch,'evidence':record}
    (root/'exclusivity-stop.json').write_text(json.dumps(result,indent=2)+'\n')
    if driver_live():os.kill(launch['pid'],signal.SIGTERM)
for _ in range(100):
    if (root/'launch.json').exists():break
    time.sleep(.1)
launch=json.loads((root/'launch.json').read_text())
with (root/'exclusivity-samples.jsonl').open('x') as log:
    while driver_live():
        try:
            lines=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_gpu_memory','--format=csv,noheader,nounits'],text=True,timeout=15).splitlines()
            foreign=[];owned=[];raced=[]
            for line in lines:
                pid=int(line.split(',')[0])
                try:
                    first=identity(pid);chain=[];current=first;seen=set()
                    while current['pid']>1 and current['pid'] not in seen:
                        seen.add(current['pid']);chain.append(current)
                        if current['owned'] or current['pid']==launch['pid'] or current['ppid']<=1:break
                        current=identity(current['ppid'])
                    last=identity(pid)
                    if first['start_ticks']!=last['start_ticks'] or last['state']=='Z':raced.append(pid);continue
                    if any(x['owned'] or x['pid']==launch['pid'] for x in chain):owned.append(pid)
                    else:foreign.append({'gpu_row':line,'chain':chain})
                except (FileNotFoundError,ProcessLookupError):raced.append(pid)
            record={'observed_at':time.time(),'owned_gpu_pids':owned,'foreign':foreign,'raced_pids':raced};log.write(json.dumps(record)+'\n');log.flush()
            if foreign:stop('Confirmed live foreign GPU process',record);break
        except Exception as error:
            stop('GPU exclusivity observation failed',{'error':type(error).__name__,'detail':str(error)});break
        time.sleep(2)
