import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess

root = Path(__file__).resolve().parent
plan = json.loads((root / 'plan.json').read_text())
inputs = json.loads((root / 'files.json').read_text())
assert all(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest for name, digest in inputs.items())
prep = Path(plan['preparation_root'])
prepared = json.loads((prep / 'prepare-driver-result.json').read_text())
assert prepared['status'] == 'complete' and prepared['cleanup_returncode'] == 0
assert json.loads((prep / 'prepare-result.json').read_text())['status'] == 'prepared_requires_gpu_validation'
assert not json.loads((prep / 'prepare-cleanup.json').read_text())['remaining_pids']
download = json.loads((prep / 'nvfp4-verification.json').read_text())
assert download['revision'] == plan['model_revisions']['nvfp4'] and len(download['files']) == 163 and download['bytes'] == 439756337764
for model, hashes in [(plan['model'], plan['model_metadata']), (plan['draft_model'], plan['draft_metadata'])]:
    for name, expected in hashes.items():
        assert hashlib.sha256((Path(model) / name).read_bytes()).hexdigest() == expected, (model, name)
source = json.loads(subprocess.check_output(['python3', str(root / 'verify_source.py'), str(root / 'source-manifest.json'), plan['source']], text=True))
assert source['revision'] == plan['runtime'] and source['verified_files'] == 12586 and not source['mismatches']
for previous in plan['prerequisite_roots']:
    prior = Path(previous)
    assert (prior / 'driver.exit').exists(), 'Controlled FP8 KV predecessor still active'
    assert (prior / 'driver.exit').read_text().strip() == '0'
    assert not json.loads((prior / 'cleanup.json').read_text())['remaining_pids']
    assert not json.loads((prior / 'postrun-source-verification.json').read_text())['mismatches']
    identity = json.loads((prior / 'launch.json').read_text())
    try:
        fields = Path(f"/proc/{identity['pid']}/stat").read_text().rsplit(')', 1)[1].split()
        assert fields[0] == 'Z' or fields[19] != identity['start_ticks']
    except FileNotFoundError:
        pass
if plan['precision'] == 'nvfp4':
    prior = Path(plan['paired_fp8_root'])
    assert (prior / 'driver.exit').read_text().strip() == '0'
    assert not json.loads((prior / 'cleanup.json').read_text())['remaining_pids']
    assert not json.loads((prior / 'postrun-source-verification.json').read_text())['mismatches']
    identity = json.loads((prior / 'launch.json').read_text())
    try:
        fields = Path(f"/proc/{identity['pid']}/stat").read_text().rsplit(')', 1)[1].split()
        assert fields[0] == 'Z' or fields[19] != identity['start_ticks']
    except FileNotFoundError:
        pass
gpus = subprocess.check_output(['nvidia-smi', '--query-gpu=name,uuid,memory.used,utilization.gpu', '--format=csv,noheader,nounits'], text=True).splitlines()
assert len(gpus) == 8 and all('NVIDIA B300 ' in line and int(line.split(',')[2]) <= 1000 and int(line.split(',')[3]) == 0 for line in gpus), gpus
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
for port in [plan['port'], plan['dist_port']]:
    with socket.socket() as connection:
        connection.bind(('127.0.0.1', port))
env = {k: v for k, v in os.environ.items() if k in ('PATH', 'HOME', 'LANG', 'LC_ALL', 'LD_LIBRARY_PATH')}
env.update(PYTHONPATH=plan['overlay'] + ':' + plan['source'] + '/python', PYTHONNOUSERSITE='1')
code = 'import importlib.metadata as m,json,sys;print(json.dumps({n:m.version(n) for n in json.loads(sys.argv[1])}))'
versions = json.loads(subprocess.check_output(['/opt/sglang/bin/python', '-c', code, json.dumps(list(plan['package_versions']))], text=True, env=env, timeout=30))
assert versions == plan['package_versions'], versions
env.update(plan['network_environment'])
bootstrap = json.loads(subprocess.check_output(['/opt/sglang/bin/python', str(root / 'nccl-bootstrap.py')], env=env, text=True, timeout=30))
assert bootstrap['code'] == 0
(root / 'nccl-preflight.json').write_text(json.dumps(bootstrap, indent=2) + '\n')
print(json.dumps({'files_verified': len(inputs), 'source': source, 'versions': versions, 'gpus': gpus, 'precision': plan['precision'], 'nvfp4_full_inventory_verified': 163, 'model_metadata_verified': True}))

prior = Path(plan['interrupted_predecessor_root'])
assert (prior / 'driver.exit').read_text().strip() == '143'
assert not json.loads((prior / 'cleanup.json').read_text())['remaining_pids']
assert not json.loads((prior / 'postrun-source-verification.json').read_text())['mismatches']
assert json.loads((prior / 'operator-stop.json').read_text())['evaluation_not_started']
assert not (prior / 'results/dep8/eval-command.txt').exists()
assert not (prior / 'results/dep8/eval-t1').exists()
identity = json.loads((prior / 'launch.json').read_text())
try:
    fields = Path(f"/proc/{identity['pid']}/stat").read_text().rsplit(')', 1)[1].split()
    assert fields[0] == 'Z' or fields[19] != identity['start_ticks']
except FileNotFoundError:
    pass
subprocess.run(['python3', str(root / 'idle-check.py')], check=True)
