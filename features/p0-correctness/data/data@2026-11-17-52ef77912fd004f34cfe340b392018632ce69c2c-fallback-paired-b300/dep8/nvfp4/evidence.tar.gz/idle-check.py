
import json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
samples=[]
for index in range(10):
    compute=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True,timeout=15).strip()
    gpus=subprocess.check_output(['nvidia-smi','--query-gpu=memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True,timeout=15).splitlines()
    supervisors=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name)==os.getpid():continue
        try:
            fields=(p/'stat').read_text().rsplit(')',1)[1].split()
            if fields[0]=='Z':continue
            argv=(p/'cmdline').read_bytes().decode(errors='replace').rstrip('\0').split('\0')
            if '-c' in argv or any(str(root) in a for a in argv):continue
            cwd=str((p/'cwd').resolve())
            scripts=[a for a in argv if a.endswith(('.py','.sh'))]
            if scripts and (cwd.startswith('/scratch/') or any(a.startswith('/scratch/') for a in scripts)):
                supervisors.append({'pid':int(p.name),'start_ticks':fields[19],'cwd':cwd,'scripts':scripts})
        except (FileNotFoundError,ProcessLookupError):pass
    sample={'observed_at':time.time(),'compute':compute,'gpu_memory_utilization':gpus,'foreign_supervisors':supervisors};samples.append(sample)
    (root/'idle-check.json').write_text(json.dumps(samples,indent=2)+'\n')
    assert not compute and not supervisors,sample
    assert len(gpus)==8 and all(int(x.split(',')[0])<=1000 and int(x.split(',')[1])==0 for x in gpus),sample
    if index<9:time.sleep(1)
