# Candidate H200 Python TreeCore reference

Full GSM8K 1319, T1/top_p0.95/seed1, 64 threads, max32768. Candidate 52ef77912fd004f34cfe340b392018632ce69c2c. Same E22 checkpoint, dependencies, service and workload; explicit Python TreeCore replaces default Rust. Eight live worker identities, Python construction logs, process environments and absence of a mapped mem_cache extension are required. Six-hour watchdog and owner-specific cleanup. This reference preserves all outputs and does not relax the quality gate.
