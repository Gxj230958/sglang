import json,pathlib,re,sys,urllib.request
out=pathlib.Path(sys.argv[3]).parent
lines=[line for line in (out/'serve.log').read_text(errors='replace').splitlines() if 'Init Unified Radix Cache.' in line and 'Tree Core:' in line]
assert lines and all('Tree Core: UnifiedTreeCore' in line for line in lines),lines
ranks={int(m[1]):int(m[2]) for line in lines if (m:=re.search(r'TP(\d+)(?: EP\d+)? PID(\d+)',line))}
assert set(ranks)==set(range(8)),ranks
record={'selected':'python','lines':lines,'ranks':{}}
for rank,pid in ranks.items():
 p=pathlib.Path(f'/proc/{pid}')
 before=(p/'stat').read_text().rsplit(')',1)[1].split()
 assert before[0]!='Z'
 env=dict(x.split('=',1) for x in (p/'environ').read_bytes().decode().split('\0') if '=' in x)
 assert env.get('SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND')=='python'
 extensions=sorted({line.split()[-1] for line in (p/'maps').read_text().splitlines() if 'mem_cache' in line and '.so' in line})
 assert not extensions,('Unexpected Rust extension in Python reference worker',rank,pid)
 after=(p/'stat').read_text().rsplit(')',1)[1].split()
 assert before[19]==after[19] and after[0]!='Z'
 record['ranks'][rank]={'pid':pid,'start_ticks':before[19],'requested_tree_core':'python','extensions':extensions}
(out/'tree-core.json').write_text(json.dumps(record,indent=2))
with urllib.request.urlopen(sys.argv[1]+'/get_server_info',timeout=10) as response:info=json.load(response)
expected=json.loads(sys.argv[4])
assert all(info.get(k)==v for k,v in expected.items()),{k:info.get(k) for k in expected}
record['resolved']={k:info[k] for k in expected}
imports=json.loads((out/'server-imports.json').read_text())
assert imports['requested_tree_core']=='python' and imports['simulation']=={} and imports['fused_h64_decode']=='0'
record['simulation']=imports['simulation']
pathlib.Path(sys.argv[3]).write_text(json.dumps(record,indent=2))
