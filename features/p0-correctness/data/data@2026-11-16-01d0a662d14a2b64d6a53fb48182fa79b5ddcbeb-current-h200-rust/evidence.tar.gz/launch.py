import json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
assert str(root)=='/scratch/glm5lp-current-h200-01d0a662d1'
assert not (root/'driver.pid').exists()
subprocess.run(['python3',str(root/'preflight.py')],check=True,stdout=subprocess.DEVNULL)
env=dict(os.environ)
for k in list(env):
    if k.startswith('SGLANG_SIMULATE_ACC_') or k=='SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND':env.pop(k)
with (root/'driver.log').open('xb') as log:
    p=subprocess.Popen(['timeout','--signal=TERM','--kill-after=90s','6h','bash',str(root/'start.sh')],env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(root/'driver.pid').write_text(str(p.pid))
record={'pid':p.pid,'started':time.time(),'root':str(root)}
(root/'launch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
