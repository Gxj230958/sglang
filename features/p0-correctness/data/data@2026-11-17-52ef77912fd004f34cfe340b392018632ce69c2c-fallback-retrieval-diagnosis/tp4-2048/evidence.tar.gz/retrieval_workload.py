import random


def cases(model):
    documents={}
    result=[]
    for target in [300,3000,9000,24000,60000,110000]:
        rng=random.Random(target)
        count=max(4,target//13)
        codes=[rng.randrange(100000,999999) for _ in range(count)]
        document='\n'.join(f'Record {i}: the code is {code}.' for i,code in enumerate(codes))
        documents[target]=(document,codes)
        for index,record in enumerate([count//7,count//2,count-3]):
            result.append(('original_sequence',target,record,index>0))
    result.append(('isolated_cold',110000,4230,False))
    result.extend([('long_sequence',110000,1208,False),('long_sequence',110000,4230,True),('long_sequence',110000,8458,True)])
    output=[]
    for phase,target,record,warm in result:
        document,codes=documents[target]
        prompt=document+f'\n\nWhat is the code of Record {record}? Answer with the number only.'
        body={'model':model,'messages':[{'role':'user','content':prompt}],'temperature':0,'max_tokens':2048,'chat_template_kwargs':{'enable_thinking':False},'logprobs':True,'top_logprobs':1}
        output.append({'phase':phase,'target':target,'record':record,'expected':str(codes[record]),'expected_warm':warm,'body':body})
    return output
