#!/usr/bin/env bash
set -euo pipefail
TASK=/scratch/glm5lp-fallback-cp-retrieval-budget-52ef77912f/tp4/fp8
export S=/scratch/glm5lp-fallback-tp4-52ef77912f/src R="$TASK/results"
export M=/scratch/models/GLM-5-1028-Provider D=/scratch/models/GLM-5-1028-Provider
export OVERLAY=/scratch/glm5lp-fallback-tp4-52ef77912f-v2/overlay
export HF_HOME="$TASK/hf-home" HF_HUB_CACHE="$TASK/hf-home/hub"
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export SGLANG_FLASHINFER_NVFP4_PER_TOKEN_ACTIVATION=1 CUDA_VISIBLE_DEVICES=0,1,2,3 OMP_NUM_THREADS=4
export SOURCE_MANIFEST="$TASK/source-manifest.json" P=32230
export PYTHONNOUSERSITE=1 CARGO_BUILD_JOBS=4 SPT_NOENV=1
export NCCL_SOCKET_IFNAME=cilium_host GLOO_SOCKET_IFNAME=cilium_host NCCL_DEBUG=WARN
export SGLANG_ENABLE_GLM_LOOP_FUSED_H64_DECODE=0
export SGLANG_CACHE_DIR="$TASK/cache/sglang" TRITON_CACHE_DIR="$TASK/cache/triton"
export FLASHINFER_WORKSPACE_BASE="$TASK/cache/flashinfer" TORCH_EXTENSIONS_DIR="$TASK/cache/torch"
export GLM5LP_SWEEP_OWNER="$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["owner"])' "$TASK/plan.json")"
finish() {
  rc=$?
  trap - EXIT
  python3 "$TASK/cleanup.py" "$TASK/cleanup.json" || rc=125
  python3 "$TASK/verify_source.py" "$TASK/source-manifest.json" "$S" > "$TASK/postrun-source-verification.json" || rc=125
  nvidia-smi --query-compute-apps=pid,process_name --format=csv,noheader > "$TASK/gpu-final-processes.csv" || rc=125
  nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits > "$TASK/gpu-final-memory.csv" || rc=125
  printf '%s\n' "$rc" > "$TASK/driver.exit"
  exit "$rc"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
python3 "$TASK/preflight.py" > "$TASK/preflight-launch.json"
bash "$TASK/runner.sh"
