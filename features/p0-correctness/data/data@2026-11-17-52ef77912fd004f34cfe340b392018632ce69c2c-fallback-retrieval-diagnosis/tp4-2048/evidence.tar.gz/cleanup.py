import json
import os
import signal
import sys
import time
from pathlib import Path

owner = os.environ['GLM5LP_SWEEP_OWNER']
output = Path(sys.argv[1])
excluded = {os.getpid()}
pid = os.getpid()
while pid > 1:
    fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
    pid = int(fields[1])
    excluded.add(pid)

def identity(pid):
    try:
        path = Path(f'/proc/{pid}')
        env = (path / 'environ').read_bytes().split(b'\0')
        if ('GLM5LP_SWEEP_OWNER=' + owner).encode() not in env:
            return None
        fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
        return None if fields[0] == 'Z' else fields[19]
    except (OSError, ProcessLookupError):
        return None

targets = {int(p.name): identity(int(p.name)) for p in Path('/proc').iterdir() if p.name.isdigit() and int(p.name) not in excluded}
targets = {pid: start for pid, start in targets.items() if start is not None}
for sig in [signal.SIGTERM, signal.SIGKILL]:
    for pid, start in targets.items():
        if identity(pid) == start:
            try:
                os.kill(pid, sig)
            except ProcessLookupError:
                pass
    if sig == signal.SIGTERM:
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline and any(identity(pid) == start for pid, start in targets.items()):
            time.sleep(0.5)
remaining = [pid for pid, start in targets.items() if identity(pid) == start]
output.write_text(json.dumps({'owner': owner, 'target_pids': sorted(targets), 'remaining_pids': remaining}, indent=2) + '\n')
sys.exit(bool(remaining))
