import ctypes,hashlib,json,os,pathlib,socket
assert 'cilium_host' in dict((name,index) for index,name in socket.if_nameindex())
p=pathlib.Path('/opt/sglang/lib/python3.12/site-packages/nvidia/nccl/lib/libnccl.so.2')
lib=ctypes.CDLL(str(p));version=ctypes.c_int();lib.ncclGetVersion(ctypes.byref(version));identifier=ctypes.create_string_buffer(128);code=lib.ncclGetUniqueId(ctypes.byref(identifier))
assert code==0,code
print(json.dumps({'code':code,'version':version.value,'library_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'network_environment':{k:os.environ.get(k) for k in ['NCCL_SOCKET_IFNAME','GLOO_SOCKET_IFNAME','NCCL_DEBUG']}}))
