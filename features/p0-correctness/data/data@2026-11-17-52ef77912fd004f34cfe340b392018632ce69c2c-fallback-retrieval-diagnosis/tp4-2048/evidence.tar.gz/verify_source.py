import hashlib
import json
import os
import sys
from pathlib import Path

manifest = json.loads(Path(sys.argv[1]).read_text())
root = Path(sys.argv[2])
errors = []
for name, record in manifest['files'].items():
    p = root / name
    try:
        data = os.readlink(p).encode() if record['mode'] == '120000' else p.read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if actual != record['oid']:
            errors.append(name)
    except OSError:
        errors.append(name)
for p in (root / 'python/sglang').rglob('*'):
    if p.suffix in ('.py', '.so') and str(p.relative_to(root)) not in manifest['files']:
        errors.append('extra:' + str(p.relative_to(root)))
print(json.dumps({'revision': manifest['revision'], 'verified_files': len(manifest['files']), 'mismatches': errors}))
raise SystemExit(bool(errors))
