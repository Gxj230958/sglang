import hashlib
import json
from pathlib import Path
import sys
import time
import urllib.request

from retrieval_workload import cases

endpoint=sys.argv[1]
output=Path(sys.argv[2]);output.mkdir(exist_ok=False)
with urllib.request.urlopen(endpoint+'/v1/models',timeout=10) as response:model=json.load(response)['data'][0]['id']
rows=[]
previous_phase=None
for index,case in enumerate(cases(model)):
    phase=case['phase']
    if phase!=previous_phase:
        req=urllib.request.Request(endpoint+'/flush_cache',method='POST')
        with urllib.request.urlopen(req,timeout=20) as response:
            (output/(phase+'-flush.txt')).write_bytes(response.read())
        previous_phase=phase
    data=json.dumps(case['body']).encode()
    stem=f"{index:02d}-{phase}-{case['target']}-{case['record']}"
    (output/(stem+'-request.json')).write_bytes(data)
    started=time.time()
    req=urllib.request.Request(endpoint+'/v1/chat/completions',data=data,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=900) as response:
        raw=response.read()
    (output/(stem+'-response.json')).write_bytes(raw)
    result=json.loads(raw);choice=result['choices'][0];text=choice['message'].get('content') or ''
    cached=(result['usage'].get('prompt_tokens_details') or {}).get('cached_tokens')
    cache_valid=(cached is not None and cached>0) if case['expected_warm'] else cached==0
    row={k:v for k,v in case.items() if k!='body'}
    row.update(started=started,finished=time.time(),request_sha256=hashlib.sha256(data).hexdigest(),response_sha256=hashlib.sha256(raw).hexdigest(),text=text,finish_reason=choice['finish_reason'],prompt_tokens=result['usage']['prompt_tokens'],completion_tokens=result['usage']['completion_tokens'],cached_tokens=cached,cache_condition_passed=cache_valid,exact_answer=text.strip()==case['expected'])
    row['passed']=row['exact_answer'] and row['finish_reason']=='stop' and cache_valid
    rows.append(row)
    (output/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
assert len(rows)==22
summary={'requests':22,'exact_stopped':sum(x['exact_answer'] and x['finish_reason']=='stop' for x in rows),'cache_conditions_passed':sum(x['cache_condition_passed'] for x in rows),'failures':[x for x in rows if not x['passed']],'all_passed':all(x['passed'] for x in rows)}
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
