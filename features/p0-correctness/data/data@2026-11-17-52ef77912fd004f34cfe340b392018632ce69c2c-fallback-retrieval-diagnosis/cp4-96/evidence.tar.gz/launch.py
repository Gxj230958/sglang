import json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
assert str(root)=='/scratch/glm5lp-fallback-cp-retrieval-52ef77912f/cp4/fp8'
assert not (root/'driver.pid').exists()
subprocess.run(['python3',str(root/'preflight.py')],check=True,stdout=subprocess.DEVNULL)
env={k:v for k,v in os.environ.items() if k in ['PATH','HOME','LANG','LC_ALL','LD_LIBRARY_PATH','SSL_CERT_FILE','SSL_CERT_DIR']}
for k in list(env):
    if k.startswith('SGLANG_SIMULATE_ACC_') or k=='SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND':env.pop(k)
with (root/'driver.log').open('xb') as log:
    p=subprocess.Popen(['timeout','--signal=TERM','--kill-after=90s','90m','bash',str(root/'start.sh')],env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(root/'driver.pid').write_text(str(p.pid))
record={'pid':p.pid,'start_ticks':Path(f'/proc/{p.pid}/stat').read_text().rsplit(')',1)[1].split()[19],'started':time.time(),'root':str(root)}
(root/'launch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
