#!/usr/bin/env bash
set -uo pipefail
TASK=$(cd -- "$(dirname -- "$0")" && pwd)
export S=/scratch/codex-fi074/src
export M=/scratch/models/GLM-5-1028-Provider
export OVERLAY=/scratch/codex-fi074/overlay
export R="$TASK/results"
export HF_HOME=/scratch/codex-fi074/hf-home HF_HUB_CACHE=/scratch/codex-fi074/hf-home/hub
export SOURCE_MANIFEST="$TASK/source-manifest.json"
export P=31876
python3 "$TASK/verify_source.py" "$TASK/source-manifest.json" "$S" > "$TASK/source-verification.json" 2>&1
rc=$?
if [[ "$rc" = 0 ]]; then
  python3 "$TASK/probe.py" > "$TASK/prelaunch-probe.json"
  python3 -c 'import json,sys; sys.exit(not json.load(open(sys.argv[1]))["idle"])' "$TASK/prelaunch-probe.json"
  rc=$?
fi
if [[ "$rc" = 0 ]]; then
  timeout --signal=TERM --kill-after=60s 6h bash "$TASK/runner.sh"
  rc=$?
fi
printf '%s\n' "$rc" > "$TASK/exit-code"
exit "$rc"
