# Serve sweep report

Recommended: `tp4-auto-bcg`

## tp4-auto-bcg

Best level: `32`; metrics: `{'cache_hit': 0.7720499999999999, 'cached': 1419008, 'duration_s': 45.38657812238671, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838039, 'interactivity_p90': 32.12569885992227, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 721.9770832700754, 'sent': 512, 'total_tps': 20970.72675069233, 'total_tps_per_gpu': 5242.681687673083, 'ttft_p50': 1.742317121126689, 'ttft_p90': 2.289218406425789}`
Valid points: 6

## tp4-auto-bcg-mtp

Valid points: 0

## tp4-auto-bcg2048

Valid points: 0
