import json,pathlib,subprocess,sys,time,importlib.metadata
endpoint,model,out,expected,cap,run_eval=sys.argv[1:]
root=pathlib.Path('/scratch/codex-serve-sweep-moe')
subprocess.run([sys.executable,str(root/'rust/sanity.py'),endpoint,model,out,expected],check=True)
p=pathlib.Path(out).parent
info=json.loads((p/'resolved-before-load.json').read_text())
graph=info['cuda_graph_config']['prefill']
assert graph['backend']=='breakable',graph
assert graph['max_bs']==int(cap),graph
assert max(graph['bs'])==int(cap),graph
(p/'resolved-prefill-graph.json').write_text(json.dumps(graph,indent=2))
if run_eval=='true':
 command=['sgl-eval','run','gsm8k','--base-url',endpoint+'/v1','--model',model,'--num-examples','200','--num-threads','16','--temperature','1.0','--top-p','0.95','--seed','1','--max-tokens','16384','--no-thinking','--chat-template-kwarg','enable_thinking=false','--out-dir',str(p/'gsm8k')]
 record={'command':command,'started':time.time(),'sgl_eval_version':importlib.metadata.version('sgl-eval')}
 (p/'gsm8k-command.json').write_text(json.dumps(record,indent=2))
 try:
  with (p/'gsm8k.log').open('w') as log:
   result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=3600)
  record['returncode']=result.returncode
 except subprocess.TimeoutExpired:
  record['timeout_s']=3600
 record['ended']=time.time()
 (p/'gsm8k-execution.json').write_text(json.dumps(record,indent=2))
