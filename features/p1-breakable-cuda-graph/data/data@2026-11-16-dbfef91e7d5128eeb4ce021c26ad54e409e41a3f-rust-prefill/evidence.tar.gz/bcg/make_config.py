import copy,json,pathlib,sys
base=pathlib.Path('/tmp/codex-glm5lp-moe-stage')
cfg=json.loads((base/'rust/sweep.json').read_text())
runner=sys.argv[1]
assert runner in ['deepgemm','auto']
by_name={c['name']:c for c in cfg['candidates']}
rows=[]
for suffix,mtp,cap,evaluate in [('bcg',False,8192,True),('bcg-mtp',True,8192,False),('bcg2048',False,2048,False)]:
 c=copy.deepcopy(by_name['tp4-'+runner+('-mtp' if mtp else '')])
 c['name']='tp4-'+runner+'-'+suffix
 c['serve_args']+=['--cuda-graph-backend-prefill','breakable']
 if cap==2048:c['serve_args']+=['--cuda-graph-max-bs-prefill','2048']
 c['values'].update({'graph_cap':str(cap),'run_eval':str(evaluate).lower()})
 rows.append(c)
cfg['candidates']=rows
cfg['server']['args'].remove('--disable-prefill-cuda-graph')
cfg['correctness']['command']=['python3','/scratch/codex-serve-sweep-moe/bcg/correctness.py','{endpoint}',cfg['values']['model_path'],'{candidate_dir}/correctness.json','{resolved_expectation}','{graph_cap}','{run_eval}']
cfg['correctness']['timeout_s']=4200
(base/'bcg/sweep.json').write_text(json.dumps(cfg,indent=2))
