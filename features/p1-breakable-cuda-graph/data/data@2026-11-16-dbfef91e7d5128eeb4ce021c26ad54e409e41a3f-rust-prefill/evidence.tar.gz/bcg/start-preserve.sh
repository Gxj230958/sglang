cd /scratch/codex-serve-sweep-moe
nohup bash bcg/preserve.sh > bcg/preserve.log 2>&1 < /dev/null &
echo $! > bcg/preserve.pid
cat bcg/preserve.pid
sleep .5
