import json,pathlib
from sglang.srt.server_args import prepare_server_args
root=pathlib.Path('/scratch/codex-serve-sweep-moe')
cfg=json.loads((root/'sweep.json').read_text())
base=[s.replace('{port}','31080') for s in cfg['server']['args'] if s!='--disable-prefill-cuda-graph']+['--tp-size','4']
rows={}
for name,extra in [('omitted',[]),('disabled',['--disable-prefill-cuda-graph']),('breakable',['--cuda-graph-backend-prefill','breakable']),('breakable2048',['--cuda-graph-backend-prefill','breakable','--cuda-graph-max-bs-prefill','2048'])]:
 args=prepare_server_args(base+extra)
 args.resolve_once()
 resolved=args.resolved_dict()
 rows[name]={'prefill':resolved['cuda_graph_config']['prefill'],'decode':resolved['cuda_graph_config']['decode'],'disable_prefill_cuda_graph':args.disable_prefill_cuda_graph,'cuda_graph_backend_prefill':args.cuda_graph_backend_prefill,'locked':list(args._cuda_graph_config_locked)}
(root/'bcg/resolved-argument-controls.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows,indent=2))
