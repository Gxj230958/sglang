import collections,datetime,json,pathlib,re,statistics
root=pathlib.Path('/tmp/codex-glm5lp-serve-sweep-evidence/moe-followup')
rows=[]
for run in [root/'rust/run1',root/'bcg/run1']:
 for c in sorted((run/'candidates').glob('*')):
  info_path=c/'resolved-before-load.json'
  log_path=c/'replica-0.log'
  info=json.loads(info_path.read_text()) if info_path.exists() else {}
  lines=log_path.read_text(errors='replace').splitlines() if log_path.exists() else []
  samples=[]
  if (c/'gpu-samples.jsonl').exists():
   for line in (c/'gpu-samples.jsonl').read_text().splitlines():
    try:samples.append(json.loads(line))
    except ValueError:pass
  windows={}
  for s in samples:
   for key in s.get('active_loads',[]):
    windows.setdefault(key,[]).append(s['time'])
  prefills=[]
  for line in lines:
   m=re.search(r'^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d).*?Prefill batch.*?#new-seq: (\d+), #new-token: (\d+), #cached-token: (\d+),.*?cuda graph: (True|False)',line)
   if not m:continue
   t=datetime.datetime.fromisoformat(m[1]).replace(tzinfo=datetime.timezone.utc).timestamp()
   matching=[key for key,ts in windows.items() if min(ts)-2<=t<=max(ts)+2]
   prefills.append({'utc':m[1],'new_sequences':int(m[2]),'new_tokens':int(m[3]),'cached_tokens':int(m[4]),'graph':m[5]=='True','load_windows':matching})
  (c/'prefill-replay-audit.json').write_text(json.dumps(prefills,indent=2))
  coverage=[]
  for key in sorted(windows):
   p=[p for p in prefills if key in p['load_windows']]
   hist=collections.Counter((p['new_tokens'],p['graph']) for p in p)
   coverage.append({'load_window':key,'prefill_batches':len(p),'graph_batches':sum(x['graph'] for x in p),'new_tokens_min':min([x['new_tokens'] for x in p],default=None),'new_tokens_max':max([x['new_tokens'] for x in p],default=None),'new_tokens_median':statistics.median([x['new_tokens'] for x in p]) if p else None,'histogram':[{'new_tokens':n,'graph':g,'batches':count} for (n,g),count in sorted(hist.items())]})
  rows.append({'candidate':c.name,'run':str(run.relative_to(root)),'graph_config':info.get('cuda_graph_config'),'capture_lines':[l for l in lines if re.search(r'Capture (target|draft) (prefill|decode) CUDA graph (begin|end)',l)],'pool_lines':[l for l in lines if 'max_total_num_tokens=' in l or 'Use sliding window memory pool.' in l],'issues':[l for l in lines if re.search(r'Traceback|out of memory|Scheduler hit an exception|fallback|fall back|Disable prefill CUDA graph',l,re.I)],'load_windows':coverage,'failure':json.loads((c/'failure.json').read_text()) if (c/'failure.json').exists() else None})
(root/'bcg/graph-audit.json').write_text(json.dumps(rows,indent=2))
for r in rows:
 print(r['candidate'],r['graph_config'],'batches',sum(x['prefill_batches'] for x in r['load_windows']),'graph',sum(x['graph_batches'] for x in r['load_windows']))
