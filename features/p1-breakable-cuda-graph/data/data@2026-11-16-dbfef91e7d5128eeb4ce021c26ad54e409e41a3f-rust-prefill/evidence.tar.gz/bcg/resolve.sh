set -eu
cd /scratch/codex-serve-sweep-moe
export PYTHONPATH=/scratch/codex-serve-sweep-moe/overlay:/scratch/codex-serve-sweep-moe/src/python
export SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND=rust
export SGLANG_RUST_BUILD_MODE=auto
export SGLANG_CACHE_DIR=/scratch/codex-serve-sweep-moe/rust-cache
python3 bcg/resolve.py > bcg/resolve.log 2>&1
sgl-eval run --help > bcg/sgl-eval-help.txt
