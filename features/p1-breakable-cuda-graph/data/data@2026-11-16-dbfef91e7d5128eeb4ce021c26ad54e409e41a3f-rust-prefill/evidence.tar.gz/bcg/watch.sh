cd /scratch/codex-serve-sweep-moe
python3 - <<'PY'
import pathlib,json,time,sys
print('UTC',time.strftime('%H:%M:%S',time.gmtime()))
for c in sorted(pathlib.Path('bcg/run1/candidates').glob('*'),key=lambda c:c.stat().st_mtime):
 summaries=list(c.glob('level-*/repeat-*/summary.json'))
 print(c.name,'complete',(c/'result.json').exists(),'repeats',len(summaries))
 if (c/'failure.json').exists(): print('FAILURE',(c/'failure.json').read_text())
 if (c/'result.json').exists():continue
 for p in sorted(c.glob('level-*/result.json'),key=lambda p:float(p.parent.name[6:])):
  d=json.loads(p.read_text());m=d['metrics'];print('POINT',d['level'],d['pass'],{k:round(m[k],3) for k in ['total_tps_per_gpu','output_tps','ttft_p90','interactivity_p90'] if k in m})
 if (c/'result.json').exists():continue
 if summaries:
  p=max(summaries,key=lambda p:p.stat().st_mtime);print('REPEAT',str(p.relative_to(c)),{k:round(v,3) if isinstance(v,float) else v for k,v in json.loads(p.read_text()).items() if k in ['sent','errors','empty_responses','total_tps_per_gpu','ttft_p90','interactivity_p90','output_tps']})
 p=c/'resolved-before-load.json'
 if p.exists():
  d=json.loads(p.read_text());print('RESOLVED',{k:d.get(k) for k in ['moe_runner_backend','dsa_prefill_backend','kv_cache_dtype','speculative_algorithm']})
 p=c/'gpu-samples.jsonl'
 if p.exists():
  rows=[]
  for l in p.read_text().splitlines():
   try:rows.append(json.loads(l))
   except ValueError:pass
  bad=[r for r in rows if any(r.get(k) for k in ['sampling_error','gpus_error','processes_error']) or any(x[-1] is not True for x in r.get('processes',[]))]
  print('GPU_SAMPLES',len(rows),'SUSPECT',len(bad))
  log=c/'replica-0.log'
  if log.exists():print('TREE',[l.split('Tree Core: ')[-1] for l in log.read_text(errors='replace').splitlines() if 'Tree Core:' in l],'VERIFIED',(c/'tree-core.json').exists())
  if bad:print('SUSPECT_SAMPLE',bad[-1])
 paths=list(c.glob('level-*/repeat-*/load.log'))
 if paths:
  p=max(paths,key=lambda p:p.stat().st_mtime);print('LOAD',str(p.relative_to(c)),p.read_text(errors='replace').splitlines()[-1:])
 else:
  p=c/'replica-0.log'
  if p.exists():print('SERVER',p.read_text(errors='replace').splitlines()[-2:])
for p in pathlib.Path('bcg/run1/candidates').glob('*/gsm8k.log'):
 print('GSM8K',p.read_text(errors='replace').splitlines()[-3:])
p=pathlib.Path('bcg/preservation.status')
if p.exists():print('PRESERVATION',p.read_text())
sys.stdout.flush();time.sleep(.5)
PY
