import collections,json,pathlib,time
p=pathlib.Path('/scratch/codex-serve-sweep-moe/bcg/run1/candidates/tp4-auto-bcg')
for f in (p/'gsm8k').rglob('metrics.json'):print('METRICS',f.read_text())
for f in (p/'gsm8k').rglob('*.jsonl'):
 rows=[json.loads(l) for l in f.read_text().splitlines()]
 print('PREDICTIONS',f.name,len(rows),'KEYS',list(rows[0]))
 print('FIRST_META',{k:v for k,v in rows[0].items() if k not in ['prompt','response','messages','generated_text','model_output','raw_output','output']})
info=json.loads((p/'resolved-before-load.json').read_text())
print('GRAPH',info.get('cuda_graph_config'))
for r in info.get('internal_states',[]):print('MEMORY',r.get('memory_usage'),'TIMING',r.get('startup_time'))
print('CAPTURE',[l for l in (p/'replica-0.log').read_text().splitlines() if 'Capture' in l and ('prefill CUDA graph' in l or 'end.' in l)])
print('SANITY',[(x['response']['choices'][0]['finish_reason'],x['response']['choices'][0]['message']['content']) for x in json.loads((p/'sanity-requests.json').read_text())])
time.sleep(.5)
