set -eu
cd /scratch/codex-serve-sweep-moe
SWEEP_DRIVER=$(cat bcg/driver.pid)
while kill -0 "$SWEEP_DRIVER" 2>/dev/null; do sleep 30; done
python3 serve_sweep.py report --run-dir bcg/run1 > bcg/final-report-readback.json
nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv,noheader > bcg/gpu-after.csv
tar -czf bcg-evidence.tar.gz bcg
cp bcg-evidence.tar.gz /cluster-storage/shared/codex-glm5lp-moe-sweep-20261116/bcg-evidence.tar.gz
sha256sum bcg-evidence.tar.gz > bcg-evidence.sha256
echo COMPLETE > bcg/preservation.status
