set -eu
cd /scratch/codex-serve-sweep-moe
test "$(cat rust/preservation.status)" = COMPLETE
python3 serve_sweep.py plan --config bcg/sweep.json > bcg/plan.json
nohup python3 -u serve_sweep.py run --config bcg/sweep.json --run-dir /scratch/codex-serve-sweep-moe/bcg/run1 > bcg/driver.log 2>&1 < /dev/null &
echo $! > bcg/driver.pid
cat bcg/driver.pid
sleep .5
