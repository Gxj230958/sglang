import base64,hashlib,json,pathlib,subprocess,sys,time
log=open('/tmp/codex-glm5lp-serve-sweep-evidence/moe-followup/transfer.log','a')
remote='/scratch/codex-serve-sweep-moe/bcg-evidence.tar.gz'
cmd=['rx','devbox','run','xinyuan-gb300-1','--','python3','-c']
code="import pathlib,hashlib,json;p=pathlib.Path("+repr(remote)+");print(json.dumps({'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))"
meta=json.loads(subprocess.check_output(cmd+[code+";import sys,time;sys.stdout.flush();time.sleep(0.5)"],text=True,stderr=log))
out=bytearray()
chunk_dir=pathlib.Path('/tmp/codex-glm5lp-serve-sweep-evidence/moe-followup/transfer-chunks');chunk_dir.mkdir(exist_ok=True)
for start in range(0,meta['size'],262144):
 code="import pathlib,base64;p=pathlib.Path("+repr(remote)+");f=p.open('rb');f.seek("+str(start)+");print(base64.b64encode(f.read(262144)).decode())"
 chunk_path=chunk_dir/(meta['sha256']+'-'+str(start))
 if chunk_path.exists(): chunk=chunk_path.read_bytes()
 else:
  for attempt in range(2):
   try:
    chunk=base64.b64decode(subprocess.check_output(cmd+[code+";import sys,time;sys.stdout.flush();time.sleep(0.5)"],text=True,stderr=log).strip(),validate=True)
    assert len(chunk)==min(262144,meta['size']-start)
    chunk_path.write_bytes(chunk)
    break
   except (subprocess.CalledProcessError,ValueError,AssertionError):
    if attempt: raise
    time.sleep(2)
 assert len(chunk)==min(262144,meta['size']-start)
 out.extend(chunk)
assert hashlib.sha256(out).hexdigest()==meta['sha256']
p=pathlib.Path('/tmp/codex-glm5lp-serve-sweep-evidence/moe-followup/bcg-evidence.tar.gz');p.write_bytes(out)
print(json.dumps(meta))
subprocess.run(['tar','-xzf',str(p),'-C','/tmp/codex-glm5lp-serve-sweep-evidence/moe-followup'],check=True)
