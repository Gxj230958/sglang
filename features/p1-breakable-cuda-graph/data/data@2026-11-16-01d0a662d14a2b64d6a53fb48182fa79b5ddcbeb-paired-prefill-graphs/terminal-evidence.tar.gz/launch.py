import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
assert str(root)=='/scratch/glm5lp-paired-bcg-01d0a662d1'
assert not (root/'driver.pid').exists()
files=json.loads((root/'files.json').read_text())
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in files.items())
prior=Path('/scratch/glm5lp-paired-controlled-01d0a662d1')
assert (prior/'driver.exit').read_text().strip()=='0'
prior_pid=int((prior/'driver.pid').read_text())
assert not Path(f'/proc/{prior_pid}').exists()
assert not json.loads((prior/'cleanup.json').read_text())['remaining_pids']
assert json.loads((prior/'postrun-source-verification.json').read_text())['mismatches']==[]
for phase,points in [('gate',1),('off',6),('controlled',6)]:
    report=json.loads((prior/phase/'report.json').read_text())
    assert not report['failures'] and len(report['candidates'])==4
    assert all(len(candidate['points'])==points for candidate in report['candidates'])
probe=json.loads(subprocess.check_output(['python3','/scratch/codex-glm5lp-current-head-01d0a662d1/probe.py']))
assert probe['idle'],probe
(root/'launcher-idle.json').write_text(json.dumps(probe,indent=2))
env=dict(os.environ)
for k in list(env):
    if k.startswith('SGLANG_SIMULATE_ACC_') or k=='SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND':env.pop(k)
p=subprocess.Popen(['timeout','--signal=TERM','--kill-after=90s','6h','bash',str(root/'start.sh')],env=env,stdin=subprocess.DEVNULL,stdout=(root/'driver.log').open('wb'),stderr=subprocess.STDOUT,start_new_session=True)
(root/'driver.pid').write_text(str(p.pid))
record={'pid':p.pid,'started':time.time(),'root':str(root),'files_verified':len(files)}
(root/'launch.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record))
