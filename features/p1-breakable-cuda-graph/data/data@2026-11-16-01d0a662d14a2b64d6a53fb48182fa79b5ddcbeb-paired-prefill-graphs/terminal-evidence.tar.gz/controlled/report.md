# Serve sweep report

Recommended: `nvfp4-prefill-breakable-mtp-controlled35`

## fp8-prefill-eager-mtp-controlled35

Best level: `32`; metrics: `{'accept_length': 3.5, 'cache_hit': 0.76915, 'cached': 1413248, 'duration_s': 30.968312063021585, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1837483, 'interactivity_p90': 65.22663200756996, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 1058.129397517419, 'sent': 512, 'total_tps': 30725.716844245027, 'total_tps_per_gpu': 7681.429211061257, 'ttft_p50': 1.9866606734576635, 'ttft_p90': 2.5671907627256587}`
Valid points: 6

## nvfp4-prefill-eager-mtp-controlled35

Best level: `32`; metrics: `{'accept_length': 3.5, 'cache_hit': 0.7687999999999999, 'cached': 1412416, 'duration_s': 26.1923096049577, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1837175, 'interactivity_p90': 85.65453936668791, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 1251.0594133864452, 'sent': 512, 'total_tps': 36322.08968116751, 'total_tps_per_gpu': 9080.522420291878, 'ttft_p50': 1.9131596704246476, 'ttft_p90': 2.1741570873418823}`
Valid points: 6

## fp8-prefill-breakable-mtp-controlled35

Best level: `32`; metrics: `{'accept_length': 3.5, 'cache_hit': 0.7676000000000001, 'cached': 1410880, 'duration_s': 29.942952944431454, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838011, 'interactivity_p90': 65.31305751681, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 1094.3848443282782, 'sent': 512, 'total_tps': 31787.25409435696, 'total_tps_per_gpu': 7946.81352358924, 'ttft_p50': 2.012681623979006, 'ttft_p90': 2.435632204520516}`
Valid points: 6

## nvfp4-prefill-breakable-mtp-controlled35

Best level: `32`; metrics: `{'accept_length': 3.5, 'cache_hit': 0.7657, 'cached': 1407040, 'duration_s': 24.573110254481435, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1837647, 'interactivity_p90': 85.5215867375449, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 1333.568608308031, 'sent': 512, 'total_tps': 38727.16925840116, 'total_tps_per_gpu': 9681.79231460029, 'ttft_p50': 1.7195881951483898, 'ttft_p90': 2.0722613885300234}`
Valid points: 6
