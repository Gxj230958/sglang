import csv
import importlib.metadata as metadata
import json
import os
import pathlib
import runpy
import subprocess
import sys
import threading
import time

def main():
 expected={'SGLANG_SIMULATE_ACC_LEN':'3.5','SGLANG_SIMULATE_ACC_METHOD':'match-expected','SGLANG_SIMULATE_ACC_TOKEN_MODE':'real-draft-token'}
 simulation={k:v for k,v in os.environ.items() if k.startswith('SGLANG_SIMULATE_ACC_')}
 assert not simulation or simulation==expected,simulation
 os.environ.pop('SGLANG_UNIFIED_RADIX_TREE_CORE_BACKEND',None)
 out=pathlib.Path(sys.argv.pop(1))
 out.mkdir(parents=True,exist_ok=True)
 parent=os.getpid()
 stop=threading.Event()

 def owned(pid):
  seen=set()
  while pid>1 and pid not in seen:
   if pid==parent:return True
   seen.add(pid)
   try:pid=int(pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[1])
   except (OSError,ValueError,IndexError):return None
  return False

 def sample():
  record={'time':time.time(),'server_pid':parent}
  for key,query in [('gpus','--query-gpu=index,uuid,memory.used,utilization.gpu'),('processes','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory')]:
   p=subprocess.run(['nvidia-smi',query,'--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10)
   record[key]=list(csv.reader(p.stdout.splitlines()))
   if p.returncode:record[key+'_error']=p.stderr.strip()
  for row in record.get('processes',[]):
   if len(row)>1 and row[1].strip().isdigit():row.append(owned(int(row[1])))
  return record

 pre=sample()
 (out/'gpu-before.json').write_text(json.dumps(pre,indent=2))
 assert all(int(row[2])<=1000 for row in pre['gpus']),pre
 assert not pre['processes'],pre

 def monitor():
  with (out/'gpu-samples.jsonl').open('a',buffering=1) as f:
   while not stop.is_set():
    try:
     r=sample()
     r['active_loads']=[]
     for p in out.glob('level-*/repeat-*/load.process.json'):
      try:
       d=json.loads(p.read_text())
       if pathlib.Path(f"/proc/{d['pid']}").exists():r['active_loads'].append(str(p.relative_to(out)))
      except (OSError,ValueError,KeyError):pass
     f.write(json.dumps(r)+'\n')
    except Exception as e:f.write(json.dumps({'time':time.time(),'sampling_error':repr(e)})+'\n')
    stop.wait(2)
 threading.Thread(target=monitor,daemon=True).start()
 try:
  import flashinfer
  import sglang
  import torch
  names=['flashinfer-python','flashinfer-cubin','flashinfer-jit-cache','flashinfer-jit-cache-sm103a','sglang-kernel','sgl-deep-gemm','sgl-flash-mla','kernels','torch','transformers']
  record={'pid':parent,'simulation':simulation,'versions':{n:metadata.version(n) for n in names},'flashinfer_file':flashinfer.__file__,'sglang_file':sglang.__file__,'torch_cuda':torch.version.cuda,'jit_providers':[{'id':x.provider_id,'version':x.version,'path':str(x.jit_cache_dir)} for x in __import__('flashinfer_jit_cache').get_jit_cache_providers()]}
  (out/'server-imports.json').write_text(json.dumps(record,indent=2))
  print('SERVER_IMPORTS '+json.dumps(record),flush=True)
  runpy.run_module('sglang.launch_server',run_name='__main__')
 finally:stop.set()

if __name__ == '__main__':
 main()
