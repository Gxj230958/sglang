# Serve sweep report

Recommended: `nvfp4-prefill-breakable-mtp-natural`

## fp8-prefill-eager-mtp-natural

Best level: `4`; metrics: `{'accept_length': 2.464744204236805, 'cache_hit': 0.7565, 'cached': 347648, 'duration_s': 40.64363171055447, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 459528, 'interactivity_p90': 43.700481106221446, 'level': 4.0, 'ok': 128, 'ok_ratio': 1.0, 'output': 16384, 'output_tps': 201.56312322734345, 'sent': 128, 'total_tps': 5854.876712869549, 'total_tps_per_gpu': 1463.7191782173873, 'ttft_p50': 0.3956462317146361, 'ttft_p90': 0.7378808376844972}`
Valid points: 3

## nvfp4-prefill-eager-mtp-natural

Best level: `4`; metrics: `{'accept_length': 2.4638741555458434, 'cache_hit': 0.7506, 'cached': 344960, 'duration_s': 37.25988041306846, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 459566, 'interactivity_p90': 52.85975123277359, 'level': 4.0, 'ok': 128, 'ok_ratio': 1.0, 'output': 16384, 'output_tps': 219.8613677256276, 'sent': 128, 'total_tps': 6386.902817389109, 'total_tps_per_gpu': 1596.7257043472773, 'ttft_p50': 0.4005563845275901, 'ttft_p90': 0.7482141656568274}`
Valid points: 3

## fp8-prefill-breakable-mtp-natural

Best level: `8`; metrics: `{'accept_length': 2.434814256078144, 'cache_hit': 0.74255, 'cached': 341248, 'duration_s': 20.332612108439207, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 459554, 'interactivity_p90': 32.81310601238907, 'level': 8.0, 'ok': 128, 'ok_ratio': 1.0, 'output': 16384, 'output_tps': 402.9402645357575, 'sent': 128, 'total_tps': 11704.989203632096, 'total_tps_per_gpu': 2926.247300908024, 'ttft_p50': 0.19384717958746478, 'ttft_p90': 1.1187478099367587}`
Valid points: 4

## nvfp4-prefill-breakable-mtp-natural

Best level: `8`; metrics: `{'accept_length': 2.453803116400479, 'cache_hit': 0.74245, 'cached': 341184, 'duration_s': 16.149105324526317, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 459547, 'interactivity_p90': 39.619471419155474, 'level': 8.0, 'ok': 128, 'ok_ratio': 1.0, 'output': 16384, 'output_tps': 507.71725322549435, 'sent': 128, 'total_tps': 14748.424361269776, 'total_tps_per_gpu': 3687.106090317444, 'ttft_p50': 0.16045348421903327, 'ttft_p90': 0.9370999123784719}`
Valid points: 4
