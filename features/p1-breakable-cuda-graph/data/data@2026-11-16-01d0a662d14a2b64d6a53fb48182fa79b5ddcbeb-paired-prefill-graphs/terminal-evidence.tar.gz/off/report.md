# Serve sweep report

Recommended: `nvfp4-prefill-breakable-mtp-off`

## fp8-prefill-eager-mtp-off

Best level: `32`; metrics: `{'cache_hit': 0.7724, 'cached': 1419840, 'duration_s': 46.485518350382335, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838179, 'interactivity_p90': 32.1738992761878, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 704.9092318507163, 'sent': 512, 'total_tps': 20476.47454468769, 'total_tps_per_gpu': 5119.118636171923, 'ttft_p50': 1.83573189022718, 'ttft_p90': 2.307999240991194}`
Valid points: 6

## nvfp4-prefill-eager-mtp-off

Best level: `32`; metrics: `{'cache_hit': 0.7699499999999999, 'cached': 1415296, 'duration_s': 38.369251870550215, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838147, 'interactivity_p90': 41.59715912051442, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 854.0172341334196, 'sent': 512, 'total_tps': 24807.40505110332, 'total_tps_per_gpu': 6201.85126277583, 'ttft_p50': 1.634122954972554, 'ttft_p90': 2.04731328075286}`
Valid points: 6

## fp8-prefill-breakable-mtp-off

Best level: `32`; metrics: `{'cache_hit': 0.7724, 'cached': 1419776, 'duration_s': 45.5479685444152, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838144, 'interactivity_p90': 32.004083657460285, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 719.4175265660908, 'sent': 512, 'total_tps': 20897.533482940773, 'total_tps_per_gpu': 5224.383370735193, 'ttft_p50': 1.7460587065434083, 'ttft_p90': 2.285727839975152}`
Valid points: 6

## nvfp4-prefill-breakable-mtp-off

Best level: `32`; metrics: `{'cache_hit': 0.7698, 'cached': 1415040, 'duration_s': 36.82012563047465, 'empty_rate': 0.0, 'empty_responses': 0, 'error_rate': 0.0, 'errors': 0, 'input': 1838170, 'interactivity_p90': 41.58221612371361, 'level': 32.0, 'ok': 512, 'ok_ratio': 1.0, 'output': 65536, 'output_tps': 889.993536818147, 'sent': 512, 'total_tps': 25852.750517293905, 'total_tps_per_gpu': 6463.187629323476, 'ttft_p50': 1.4918295195093378, 'ttft_p90': 1.9645390525110997}`
Valid points: 6
